"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.flavorEntries = exports.flavors = exports.version = void 0;
const palette_js_1 = __importDefault(require("./palette.js"));
const entriesFromObject = (obj) => Object.entries(obj);
const { version: _, ...jsonFlavors } = palette_js_1.default;
/**
 * The version of the Catppuccin palette.
 */
exports.version = palette_js_1.default.version;
/**
 * All flavors of Catppuccin.
 */
exports.flavors = entriesFromObject(jsonFlavors).reduce((acc, [flavorName, flavor]) => {
    acc[flavorName] = {
        ...flavor,
        colorEntries: entriesFromObject(flavor.colors),
        ansiColorEntries: entriesFromObject(flavor.ansiColors),
    };
    return acc;
}, {});
/**
 * A typed `Object.entries()` iterable of all Catppuccin flavors.
 */
exports.flavorEntries = entriesFromObject(exports.flavors);
