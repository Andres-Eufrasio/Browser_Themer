declare namespace _default {
    let version: string;
    namespace latte {
        let name: string;
        let emoji: string;
        let order: number;
        let dark: boolean;
        namespace colors {
            namespace rosewater {
                let name_1: string;
                export { name_1 as name };
                let order_1: number;
                export { order_1 as order };
                export let hex: string;
                export namespace rgb {
                    let r: number;
                    let g: number;
                    let b: number;
                }
                export namespace hsl {
                    let h: number;
                    let s: number;
                    let l: number;
                }
                export namespace oklch {
                    let l_1: number;
                    export { l_1 as l };
                    export let c: number;
                    let h_1: number;
                    export { h_1 as h };
                }
                export let accent: boolean;
            }
            namespace flamingo {
                let name_2: string;
                export { name_2 as name };
                let order_2: number;
                export { order_2 as order };
                let hex_1: string;
                export { hex_1 as hex };
                export namespace rgb_1 {
                    let r_1: number;
                    export { r_1 as r };
                    let g_1: number;
                    export { g_1 as g };
                    let b_1: number;
                    export { b_1 as b };
                }
                export { rgb_1 as rgb };
                export namespace hsl_1 {
                    let h_2: number;
                    export { h_2 as h };
                    let s_1: number;
                    export { s_1 as s };
                    let l_2: number;
                    export { l_2 as l };
                }
                export { hsl_1 as hsl };
                export namespace oklch_1 {
                    let l_3: number;
                    export { l_3 as l };
                    let c_1: number;
                    export { c_1 as c };
                    let h_3: number;
                    export { h_3 as h };
                }
                export { oklch_1 as oklch };
                let accent_1: boolean;
                export { accent_1 as accent };
            }
            namespace pink {
                let name_3: string;
                export { name_3 as name };
                let order_3: number;
                export { order_3 as order };
                let hex_2: string;
                export { hex_2 as hex };
                export namespace rgb_2 {
                    let r_2: number;
                    export { r_2 as r };
                    let g_2: number;
                    export { g_2 as g };
                    let b_2: number;
                    export { b_2 as b };
                }
                export { rgb_2 as rgb };
                export namespace hsl_2 {
                    let h_4: number;
                    export { h_4 as h };
                    let s_2: number;
                    export { s_2 as s };
                    let l_4: number;
                    export { l_4 as l };
                }
                export { hsl_2 as hsl };
                export namespace oklch_2 {
                    let l_5: number;
                    export { l_5 as l };
                    let c_2: number;
                    export { c_2 as c };
                    let h_5: number;
                    export { h_5 as h };
                }
                export { oklch_2 as oklch };
                let accent_2: boolean;
                export { accent_2 as accent };
            }
            namespace mauve {
                let name_4: string;
                export { name_4 as name };
                let order_4: number;
                export { order_4 as order };
                let hex_3: string;
                export { hex_3 as hex };
                export namespace rgb_3 {
                    let r_3: number;
                    export { r_3 as r };
                    let g_3: number;
                    export { g_3 as g };
                    let b_3: number;
                    export { b_3 as b };
                }
                export { rgb_3 as rgb };
                export namespace hsl_3 {
                    let h_6: number;
                    export { h_6 as h };
                    let s_3: number;
                    export { s_3 as s };
                    let l_6: number;
                    export { l_6 as l };
                }
                export { hsl_3 as hsl };
                export namespace oklch_3 {
                    let l_7: number;
                    export { l_7 as l };
                    let c_3: number;
                    export { c_3 as c };
                    let h_7: number;
                    export { h_7 as h };
                }
                export { oklch_3 as oklch };
                let accent_3: boolean;
                export { accent_3 as accent };
            }
            namespace red {
                let name_5: string;
                export { name_5 as name };
                let order_5: number;
                export { order_5 as order };
                let hex_4: string;
                export { hex_4 as hex };
                export namespace rgb_4 {
                    let r_4: number;
                    export { r_4 as r };
                    let g_4: number;
                    export { g_4 as g };
                    let b_4: number;
                    export { b_4 as b };
                }
                export { rgb_4 as rgb };
                export namespace hsl_4 {
                    let h_8: number;
                    export { h_8 as h };
                    let s_4: number;
                    export { s_4 as s };
                    let l_8: number;
                    export { l_8 as l };
                }
                export { hsl_4 as hsl };
                export namespace oklch_4 {
                    let l_9: number;
                    export { l_9 as l };
                    let c_4: number;
                    export { c_4 as c };
                    let h_9: number;
                    export { h_9 as h };
                }
                export { oklch_4 as oklch };
                let accent_4: boolean;
                export { accent_4 as accent };
            }
            namespace maroon {
                let name_6: string;
                export { name_6 as name };
                let order_6: number;
                export { order_6 as order };
                let hex_5: string;
                export { hex_5 as hex };
                export namespace rgb_5 {
                    let r_5: number;
                    export { r_5 as r };
                    let g_5: number;
                    export { g_5 as g };
                    let b_5: number;
                    export { b_5 as b };
                }
                export { rgb_5 as rgb };
                export namespace hsl_5 {
                    let h_10: number;
                    export { h_10 as h };
                    let s_5: number;
                    export { s_5 as s };
                    let l_10: number;
                    export { l_10 as l };
                }
                export { hsl_5 as hsl };
                export namespace oklch_5 {
                    let l_11: number;
                    export { l_11 as l };
                    let c_5: number;
                    export { c_5 as c };
                    let h_11: number;
                    export { h_11 as h };
                }
                export { oklch_5 as oklch };
                let accent_5: boolean;
                export { accent_5 as accent };
            }
            namespace peach {
                let name_7: string;
                export { name_7 as name };
                let order_7: number;
                export { order_7 as order };
                let hex_6: string;
                export { hex_6 as hex };
                export namespace rgb_6 {
                    let r_6: number;
                    export { r_6 as r };
                    let g_6: number;
                    export { g_6 as g };
                    let b_6: number;
                    export { b_6 as b };
                }
                export { rgb_6 as rgb };
                export namespace hsl_6 {
                    let h_12: number;
                    export { h_12 as h };
                    let s_6: number;
                    export { s_6 as s };
                    let l_12: number;
                    export { l_12 as l };
                }
                export { hsl_6 as hsl };
                export namespace oklch_6 {
                    let l_13: number;
                    export { l_13 as l };
                    let c_6: number;
                    export { c_6 as c };
                    let h_13: number;
                    export { h_13 as h };
                }
                export { oklch_6 as oklch };
                let accent_6: boolean;
                export { accent_6 as accent };
            }
            namespace yellow {
                let name_8: string;
                export { name_8 as name };
                let order_8: number;
                export { order_8 as order };
                let hex_7: string;
                export { hex_7 as hex };
                export namespace rgb_7 {
                    let r_7: number;
                    export { r_7 as r };
                    let g_7: number;
                    export { g_7 as g };
                    let b_7: number;
                    export { b_7 as b };
                }
                export { rgb_7 as rgb };
                export namespace hsl_7 {
                    let h_14: number;
                    export { h_14 as h };
                    let s_7: number;
                    export { s_7 as s };
                    let l_14: number;
                    export { l_14 as l };
                }
                export { hsl_7 as hsl };
                export namespace oklch_7 {
                    let l_15: number;
                    export { l_15 as l };
                    let c_7: number;
                    export { c_7 as c };
                    let h_15: number;
                    export { h_15 as h };
                }
                export { oklch_7 as oklch };
                let accent_7: boolean;
                export { accent_7 as accent };
            }
            namespace green {
                let name_9: string;
                export { name_9 as name };
                let order_9: number;
                export { order_9 as order };
                let hex_8: string;
                export { hex_8 as hex };
                export namespace rgb_8 {
                    let r_8: number;
                    export { r_8 as r };
                    let g_8: number;
                    export { g_8 as g };
                    let b_8: number;
                    export { b_8 as b };
                }
                export { rgb_8 as rgb };
                export namespace hsl_8 {
                    let h_16: number;
                    export { h_16 as h };
                    let s_8: number;
                    export { s_8 as s };
                    let l_16: number;
                    export { l_16 as l };
                }
                export { hsl_8 as hsl };
                export namespace oklch_8 {
                    let l_17: number;
                    export { l_17 as l };
                    let c_8: number;
                    export { c_8 as c };
                    let h_17: number;
                    export { h_17 as h };
                }
                export { oklch_8 as oklch };
                let accent_8: boolean;
                export { accent_8 as accent };
            }
            namespace teal {
                let name_10: string;
                export { name_10 as name };
                let order_10: number;
                export { order_10 as order };
                let hex_9: string;
                export { hex_9 as hex };
                export namespace rgb_9 {
                    let r_9: number;
                    export { r_9 as r };
                    let g_9: number;
                    export { g_9 as g };
                    let b_9: number;
                    export { b_9 as b };
                }
                export { rgb_9 as rgb };
                export namespace hsl_9 {
                    let h_18: number;
                    export { h_18 as h };
                    let s_9: number;
                    export { s_9 as s };
                    let l_18: number;
                    export { l_18 as l };
                }
                export { hsl_9 as hsl };
                export namespace oklch_9 {
                    let l_19: number;
                    export { l_19 as l };
                    let c_9: number;
                    export { c_9 as c };
                    let h_19: number;
                    export { h_19 as h };
                }
                export { oklch_9 as oklch };
                let accent_9: boolean;
                export { accent_9 as accent };
            }
            namespace sky {
                let name_11: string;
                export { name_11 as name };
                let order_11: number;
                export { order_11 as order };
                let hex_10: string;
                export { hex_10 as hex };
                export namespace rgb_10 {
                    let r_10: number;
                    export { r_10 as r };
                    let g_10: number;
                    export { g_10 as g };
                    let b_10: number;
                    export { b_10 as b };
                }
                export { rgb_10 as rgb };
                export namespace hsl_10 {
                    let h_20: number;
                    export { h_20 as h };
                    let s_10: number;
                    export { s_10 as s };
                    let l_20: number;
                    export { l_20 as l };
                }
                export { hsl_10 as hsl };
                export namespace oklch_10 {
                    let l_21: number;
                    export { l_21 as l };
                    let c_10: number;
                    export { c_10 as c };
                    let h_21: number;
                    export { h_21 as h };
                }
                export { oklch_10 as oklch };
                let accent_10: boolean;
                export { accent_10 as accent };
            }
            namespace sapphire {
                let name_12: string;
                export { name_12 as name };
                let order_12: number;
                export { order_12 as order };
                let hex_11: string;
                export { hex_11 as hex };
                export namespace rgb_11 {
                    let r_11: number;
                    export { r_11 as r };
                    let g_11: number;
                    export { g_11 as g };
                    let b_11: number;
                    export { b_11 as b };
                }
                export { rgb_11 as rgb };
                export namespace hsl_11 {
                    let h_22: number;
                    export { h_22 as h };
                    let s_11: number;
                    export { s_11 as s };
                    let l_22: number;
                    export { l_22 as l };
                }
                export { hsl_11 as hsl };
                export namespace oklch_11 {
                    let l_23: number;
                    export { l_23 as l };
                    let c_11: number;
                    export { c_11 as c };
                    let h_23: number;
                    export { h_23 as h };
                }
                export { oklch_11 as oklch };
                let accent_11: boolean;
                export { accent_11 as accent };
            }
            namespace blue {
                let name_13: string;
                export { name_13 as name };
                let order_13: number;
                export { order_13 as order };
                let hex_12: string;
                export { hex_12 as hex };
                export namespace rgb_12 {
                    let r_12: number;
                    export { r_12 as r };
                    let g_12: number;
                    export { g_12 as g };
                    let b_12: number;
                    export { b_12 as b };
                }
                export { rgb_12 as rgb };
                export namespace hsl_12 {
                    let h_24: number;
                    export { h_24 as h };
                    let s_12: number;
                    export { s_12 as s };
                    let l_24: number;
                    export { l_24 as l };
                }
                export { hsl_12 as hsl };
                export namespace oklch_12 {
                    let l_25: number;
                    export { l_25 as l };
                    let c_12: number;
                    export { c_12 as c };
                    let h_25: number;
                    export { h_25 as h };
                }
                export { oklch_12 as oklch };
                let accent_12: boolean;
                export { accent_12 as accent };
            }
            namespace lavender {
                let name_14: string;
                export { name_14 as name };
                let order_14: number;
                export { order_14 as order };
                let hex_13: string;
                export { hex_13 as hex };
                export namespace rgb_13 {
                    let r_13: number;
                    export { r_13 as r };
                    let g_13: number;
                    export { g_13 as g };
                    let b_13: number;
                    export { b_13 as b };
                }
                export { rgb_13 as rgb };
                export namespace hsl_13 {
                    let h_26: number;
                    export { h_26 as h };
                    let s_13: number;
                    export { s_13 as s };
                    let l_26: number;
                    export { l_26 as l };
                }
                export { hsl_13 as hsl };
                export namespace oklch_13 {
                    let l_27: number;
                    export { l_27 as l };
                    let c_13: number;
                    export { c_13 as c };
                    let h_27: number;
                    export { h_27 as h };
                }
                export { oklch_13 as oklch };
                let accent_13: boolean;
                export { accent_13 as accent };
            }
            namespace text {
                let name_15: string;
                export { name_15 as name };
                let order_15: number;
                export { order_15 as order };
                let hex_14: string;
                export { hex_14 as hex };
                export namespace rgb_14 {
                    let r_14: number;
                    export { r_14 as r };
                    let g_14: number;
                    export { g_14 as g };
                    let b_14: number;
                    export { b_14 as b };
                }
                export { rgb_14 as rgb };
                export namespace hsl_14 {
                    let h_28: number;
                    export { h_28 as h };
                    let s_14: number;
                    export { s_14 as s };
                    let l_28: number;
                    export { l_28 as l };
                }
                export { hsl_14 as hsl };
                export namespace oklch_14 {
                    let l_29: number;
                    export { l_29 as l };
                    let c_14: number;
                    export { c_14 as c };
                    let h_29: number;
                    export { h_29 as h };
                }
                export { oklch_14 as oklch };
                let accent_14: boolean;
                export { accent_14 as accent };
            }
            namespace subtext1 {
                let name_16: string;
                export { name_16 as name };
                let order_16: number;
                export { order_16 as order };
                let hex_15: string;
                export { hex_15 as hex };
                export namespace rgb_15 {
                    let r_15: number;
                    export { r_15 as r };
                    let g_15: number;
                    export { g_15 as g };
                    let b_15: number;
                    export { b_15 as b };
                }
                export { rgb_15 as rgb };
                export namespace hsl_15 {
                    let h_30: number;
                    export { h_30 as h };
                    let s_15: number;
                    export { s_15 as s };
                    let l_30: number;
                    export { l_30 as l };
                }
                export { hsl_15 as hsl };
                export namespace oklch_15 {
                    let l_31: number;
                    export { l_31 as l };
                    let c_15: number;
                    export { c_15 as c };
                    let h_31: number;
                    export { h_31 as h };
                }
                export { oklch_15 as oklch };
                let accent_15: boolean;
                export { accent_15 as accent };
            }
            namespace subtext0 {
                let name_17: string;
                export { name_17 as name };
                let order_17: number;
                export { order_17 as order };
                let hex_16: string;
                export { hex_16 as hex };
                export namespace rgb_16 {
                    let r_16: number;
                    export { r_16 as r };
                    let g_16: number;
                    export { g_16 as g };
                    let b_16: number;
                    export { b_16 as b };
                }
                export { rgb_16 as rgb };
                export namespace hsl_16 {
                    let h_32: number;
                    export { h_32 as h };
                    let s_16: number;
                    export { s_16 as s };
                    let l_32: number;
                    export { l_32 as l };
                }
                export { hsl_16 as hsl };
                export namespace oklch_16 {
                    let l_33: number;
                    export { l_33 as l };
                    let c_16: number;
                    export { c_16 as c };
                    let h_33: number;
                    export { h_33 as h };
                }
                export { oklch_16 as oklch };
                let accent_16: boolean;
                export { accent_16 as accent };
            }
            namespace overlay2 {
                let name_18: string;
                export { name_18 as name };
                let order_18: number;
                export { order_18 as order };
                let hex_17: string;
                export { hex_17 as hex };
                export namespace rgb_17 {
                    let r_17: number;
                    export { r_17 as r };
                    let g_17: number;
                    export { g_17 as g };
                    let b_17: number;
                    export { b_17 as b };
                }
                export { rgb_17 as rgb };
                export namespace hsl_17 {
                    let h_34: number;
                    export { h_34 as h };
                    let s_17: number;
                    export { s_17 as s };
                    let l_34: number;
                    export { l_34 as l };
                }
                export { hsl_17 as hsl };
                export namespace oklch_17 {
                    let l_35: number;
                    export { l_35 as l };
                    let c_17: number;
                    export { c_17 as c };
                    let h_35: number;
                    export { h_35 as h };
                }
                export { oklch_17 as oklch };
                let accent_17: boolean;
                export { accent_17 as accent };
            }
            namespace overlay1 {
                let name_19: string;
                export { name_19 as name };
                let order_19: number;
                export { order_19 as order };
                let hex_18: string;
                export { hex_18 as hex };
                export namespace rgb_18 {
                    let r_18: number;
                    export { r_18 as r };
                    let g_18: number;
                    export { g_18 as g };
                    let b_18: number;
                    export { b_18 as b };
                }
                export { rgb_18 as rgb };
                export namespace hsl_18 {
                    let h_36: number;
                    export { h_36 as h };
                    let s_18: number;
                    export { s_18 as s };
                    let l_36: number;
                    export { l_36 as l };
                }
                export { hsl_18 as hsl };
                export namespace oklch_18 {
                    let l_37: number;
                    export { l_37 as l };
                    let c_18: number;
                    export { c_18 as c };
                    let h_37: number;
                    export { h_37 as h };
                }
                export { oklch_18 as oklch };
                let accent_18: boolean;
                export { accent_18 as accent };
            }
            namespace overlay0 {
                let name_20: string;
                export { name_20 as name };
                let order_20: number;
                export { order_20 as order };
                let hex_19: string;
                export { hex_19 as hex };
                export namespace rgb_19 {
                    let r_19: number;
                    export { r_19 as r };
                    let g_19: number;
                    export { g_19 as g };
                    let b_19: number;
                    export { b_19 as b };
                }
                export { rgb_19 as rgb };
                export namespace hsl_19 {
                    let h_38: number;
                    export { h_38 as h };
                    let s_19: number;
                    export { s_19 as s };
                    let l_38: number;
                    export { l_38 as l };
                }
                export { hsl_19 as hsl };
                export namespace oklch_19 {
                    let l_39: number;
                    export { l_39 as l };
                    let c_19: number;
                    export { c_19 as c };
                    let h_39: number;
                    export { h_39 as h };
                }
                export { oklch_19 as oklch };
                let accent_19: boolean;
                export { accent_19 as accent };
            }
            namespace surface2 {
                let name_21: string;
                export { name_21 as name };
                let order_21: number;
                export { order_21 as order };
                let hex_20: string;
                export { hex_20 as hex };
                export namespace rgb_20 {
                    let r_20: number;
                    export { r_20 as r };
                    let g_20: number;
                    export { g_20 as g };
                    let b_20: number;
                    export { b_20 as b };
                }
                export { rgb_20 as rgb };
                export namespace hsl_20 {
                    let h_40: number;
                    export { h_40 as h };
                    let s_20: number;
                    export { s_20 as s };
                    let l_40: number;
                    export { l_40 as l };
                }
                export { hsl_20 as hsl };
                export namespace oklch_20 {
                    let l_41: number;
                    export { l_41 as l };
                    let c_20: number;
                    export { c_20 as c };
                    let h_41: number;
                    export { h_41 as h };
                }
                export { oklch_20 as oklch };
                let accent_20: boolean;
                export { accent_20 as accent };
            }
            namespace surface1 {
                let name_22: string;
                export { name_22 as name };
                let order_22: number;
                export { order_22 as order };
                let hex_21: string;
                export { hex_21 as hex };
                export namespace rgb_21 {
                    let r_21: number;
                    export { r_21 as r };
                    let g_21: number;
                    export { g_21 as g };
                    let b_21: number;
                    export { b_21 as b };
                }
                export { rgb_21 as rgb };
                export namespace hsl_21 {
                    let h_42: number;
                    export { h_42 as h };
                    let s_21: number;
                    export { s_21 as s };
                    let l_42: number;
                    export { l_42 as l };
                }
                export { hsl_21 as hsl };
                export namespace oklch_21 {
                    let l_43: number;
                    export { l_43 as l };
                    let c_21: number;
                    export { c_21 as c };
                    let h_43: number;
                    export { h_43 as h };
                }
                export { oklch_21 as oklch };
                let accent_21: boolean;
                export { accent_21 as accent };
            }
            namespace surface0 {
                let name_23: string;
                export { name_23 as name };
                let order_23: number;
                export { order_23 as order };
                let hex_22: string;
                export { hex_22 as hex };
                export namespace rgb_22 {
                    let r_22: number;
                    export { r_22 as r };
                    let g_22: number;
                    export { g_22 as g };
                    let b_22: number;
                    export { b_22 as b };
                }
                export { rgb_22 as rgb };
                export namespace hsl_22 {
                    let h_44: number;
                    export { h_44 as h };
                    let s_22: number;
                    export { s_22 as s };
                    let l_44: number;
                    export { l_44 as l };
                }
                export { hsl_22 as hsl };
                export namespace oklch_22 {
                    let l_45: number;
                    export { l_45 as l };
                    let c_22: number;
                    export { c_22 as c };
                    let h_45: number;
                    export { h_45 as h };
                }
                export { oklch_22 as oklch };
                let accent_22: boolean;
                export { accent_22 as accent };
            }
            namespace base {
                let name_24: string;
                export { name_24 as name };
                let order_24: number;
                export { order_24 as order };
                let hex_23: string;
                export { hex_23 as hex };
                export namespace rgb_23 {
                    let r_23: number;
                    export { r_23 as r };
                    let g_23: number;
                    export { g_23 as g };
                    let b_23: number;
                    export { b_23 as b };
                }
                export { rgb_23 as rgb };
                export namespace hsl_23 {
                    let h_46: number;
                    export { h_46 as h };
                    let s_23: number;
                    export { s_23 as s };
                    let l_46: number;
                    export { l_46 as l };
                }
                export { hsl_23 as hsl };
                export namespace oklch_23 {
                    let l_47: number;
                    export { l_47 as l };
                    let c_23: number;
                    export { c_23 as c };
                    let h_47: number;
                    export { h_47 as h };
                }
                export { oklch_23 as oklch };
                let accent_23: boolean;
                export { accent_23 as accent };
            }
            namespace mantle {
                let name_25: string;
                export { name_25 as name };
                let order_25: number;
                export { order_25 as order };
                let hex_24: string;
                export { hex_24 as hex };
                export namespace rgb_24 {
                    let r_24: number;
                    export { r_24 as r };
                    let g_24: number;
                    export { g_24 as g };
                    let b_24: number;
                    export { b_24 as b };
                }
                export { rgb_24 as rgb };
                export namespace hsl_24 {
                    let h_48: number;
                    export { h_48 as h };
                    let s_24: number;
                    export { s_24 as s };
                    let l_48: number;
                    export { l_48 as l };
                }
                export { hsl_24 as hsl };
                export namespace oklch_24 {
                    let l_49: number;
                    export { l_49 as l };
                    let c_24: number;
                    export { c_24 as c };
                    let h_49: number;
                    export { h_49 as h };
                }
                export { oklch_24 as oklch };
                let accent_24: boolean;
                export { accent_24 as accent };
            }
            namespace crust {
                let name_26: string;
                export { name_26 as name };
                let order_26: number;
                export { order_26 as order };
                let hex_25: string;
                export { hex_25 as hex };
                export namespace rgb_25 {
                    let r_25: number;
                    export { r_25 as r };
                    let g_25: number;
                    export { g_25 as g };
                    let b_25: number;
                    export { b_25 as b };
                }
                export { rgb_25 as rgb };
                export namespace hsl_25 {
                    let h_50: number;
                    export { h_50 as h };
                    let s_25: number;
                    export { s_25 as s };
                    let l_50: number;
                    export { l_50 as l };
                }
                export { hsl_25 as hsl };
                export namespace oklch_25 {
                    let l_51: number;
                    export { l_51 as l };
                    let c_25: number;
                    export { c_25 as c };
                    let h_51: number;
                    export { h_51 as h };
                }
                export { oklch_25 as oklch };
                let accent_25: boolean;
                export { accent_25 as accent };
            }
        }
        namespace ansiColors {
            export namespace black {
                let name_27: string;
                export { name_27 as name };
                let order_27: number;
                export { order_27 as order };
                export namespace normal {
                    let name_28: string;
                    export { name_28 as name };
                    let hex_26: string;
                    export { hex_26 as hex };
                    export namespace rgb_26 {
                        let r_26: number;
                        export { r_26 as r };
                        let g_26: number;
                        export { g_26 as g };
                        let b_26: number;
                        export { b_26 as b };
                    }
                    export { rgb_26 as rgb };
                    export namespace hsl_26 {
                        let h_52: number;
                        export { h_52 as h };
                        let s_26: number;
                        export { s_26 as s };
                        let l_52: number;
                        export { l_52 as l };
                    }
                    export { hsl_26 as hsl };
                    export namespace oklch_26 {
                        let l_53: number;
                        export { l_53 as l };
                        let c_26: number;
                        export { c_26 as c };
                        let h_53: number;
                        export { h_53 as h };
                    }
                    export { oklch_26 as oklch };
                    export let code: number;
                }
                export namespace bright {
                    let name_29: string;
                    export { name_29 as name };
                    let hex_27: string;
                    export { hex_27 as hex };
                    export namespace rgb_27 {
                        let r_27: number;
                        export { r_27 as r };
                        let g_27: number;
                        export { g_27 as g };
                        let b_27: number;
                        export { b_27 as b };
                    }
                    export { rgb_27 as rgb };
                    export namespace hsl_27 {
                        let h_54: number;
                        export { h_54 as h };
                        let s_27: number;
                        export { s_27 as s };
                        let l_54: number;
                        export { l_54 as l };
                    }
                    export { hsl_27 as hsl };
                    export namespace oklch_27 {
                        let l_55: number;
                        export { l_55 as l };
                        let c_27: number;
                        export { c_27 as c };
                        let h_55: number;
                        export { h_55 as h };
                    }
                    export { oklch_27 as oklch };
                    let code_1: number;
                    export { code_1 as code };
                }
            }
            export namespace red_1 {
                let name_30: string;
                export { name_30 as name };
                let order_28: number;
                export { order_28 as order };
                export namespace normal_1 {
                    let name_31: string;
                    export { name_31 as name };
                    let hex_28: string;
                    export { hex_28 as hex };
                    export namespace rgb_28 {
                        let r_28: number;
                        export { r_28 as r };
                        let g_28: number;
                        export { g_28 as g };
                        let b_28: number;
                        export { b_28 as b };
                    }
                    export { rgb_28 as rgb };
                    export namespace hsl_28 {
                        let h_56: number;
                        export { h_56 as h };
                        let s_28: number;
                        export { s_28 as s };
                        let l_56: number;
                        export { l_56 as l };
                    }
                    export { hsl_28 as hsl };
                    export namespace oklch_28 {
                        let l_57: number;
                        export { l_57 as l };
                        let c_28: number;
                        export { c_28 as c };
                        let h_57: number;
                        export { h_57 as h };
                    }
                    export { oklch_28 as oklch };
                    let code_2: number;
                    export { code_2 as code };
                }
                export { normal_1 as normal };
                export namespace bright_1 {
                    let name_32: string;
                    export { name_32 as name };
                    let hex_29: string;
                    export { hex_29 as hex };
                    export namespace rgb_29 {
                        let r_29: number;
                        export { r_29 as r };
                        let g_29: number;
                        export { g_29 as g };
                        let b_29: number;
                        export { b_29 as b };
                    }
                    export { rgb_29 as rgb };
                    export namespace hsl_29 {
                        let h_58: number;
                        export { h_58 as h };
                        let s_29: number;
                        export { s_29 as s };
                        let l_58: number;
                        export { l_58 as l };
                    }
                    export { hsl_29 as hsl };
                    export namespace oklch_29 {
                        let l_59: number;
                        export { l_59 as l };
                        let c_29: number;
                        export { c_29 as c };
                        let h_59: number;
                        export { h_59 as h };
                    }
                    export { oklch_29 as oklch };
                    let code_3: number;
                    export { code_3 as code };
                }
                export { bright_1 as bright };
            }
            export { red_1 as red };
            export namespace green_1 {
                let name_33: string;
                export { name_33 as name };
                let order_29: number;
                export { order_29 as order };
                export namespace normal_2 {
                    let name_34: string;
                    export { name_34 as name };
                    let hex_30: string;
                    export { hex_30 as hex };
                    export namespace rgb_30 {
                        let r_30: number;
                        export { r_30 as r };
                        let g_30: number;
                        export { g_30 as g };
                        let b_30: number;
                        export { b_30 as b };
                    }
                    export { rgb_30 as rgb };
                    export namespace hsl_30 {
                        let h_60: number;
                        export { h_60 as h };
                        let s_30: number;
                        export { s_30 as s };
                        let l_60: number;
                        export { l_60 as l };
                    }
                    export { hsl_30 as hsl };
                    export namespace oklch_30 {
                        let l_61: number;
                        export { l_61 as l };
                        let c_30: number;
                        export { c_30 as c };
                        let h_61: number;
                        export { h_61 as h };
                    }
                    export { oklch_30 as oklch };
                    let code_4: number;
                    export { code_4 as code };
                }
                export { normal_2 as normal };
                export namespace bright_2 {
                    let name_35: string;
                    export { name_35 as name };
                    let hex_31: string;
                    export { hex_31 as hex };
                    export namespace rgb_31 {
                        let r_31: number;
                        export { r_31 as r };
                        let g_31: number;
                        export { g_31 as g };
                        let b_31: number;
                        export { b_31 as b };
                    }
                    export { rgb_31 as rgb };
                    export namespace hsl_31 {
                        let h_62: number;
                        export { h_62 as h };
                        let s_31: number;
                        export { s_31 as s };
                        let l_62: number;
                        export { l_62 as l };
                    }
                    export { hsl_31 as hsl };
                    export namespace oklch_31 {
                        let l_63: number;
                        export { l_63 as l };
                        let c_31: number;
                        export { c_31 as c };
                        let h_63: number;
                        export { h_63 as h };
                    }
                    export { oklch_31 as oklch };
                    let code_5: number;
                    export { code_5 as code };
                }
                export { bright_2 as bright };
            }
            export { green_1 as green };
            export namespace yellow_1 {
                let name_36: string;
                export { name_36 as name };
                let order_30: number;
                export { order_30 as order };
                export namespace normal_3 {
                    let name_37: string;
                    export { name_37 as name };
                    let hex_32: string;
                    export { hex_32 as hex };
                    export namespace rgb_32 {
                        let r_32: number;
                        export { r_32 as r };
                        let g_32: number;
                        export { g_32 as g };
                        let b_32: number;
                        export { b_32 as b };
                    }
                    export { rgb_32 as rgb };
                    export namespace hsl_32 {
                        let h_64: number;
                        export { h_64 as h };
                        let s_32: number;
                        export { s_32 as s };
                        let l_64: number;
                        export { l_64 as l };
                    }
                    export { hsl_32 as hsl };
                    export namespace oklch_32 {
                        let l_65: number;
                        export { l_65 as l };
                        let c_32: number;
                        export { c_32 as c };
                        let h_65: number;
                        export { h_65 as h };
                    }
                    export { oklch_32 as oklch };
                    let code_6: number;
                    export { code_6 as code };
                }
                export { normal_3 as normal };
                export namespace bright_3 {
                    let name_38: string;
                    export { name_38 as name };
                    let hex_33: string;
                    export { hex_33 as hex };
                    export namespace rgb_33 {
                        let r_33: number;
                        export { r_33 as r };
                        let g_33: number;
                        export { g_33 as g };
                        let b_33: number;
                        export { b_33 as b };
                    }
                    export { rgb_33 as rgb };
                    export namespace hsl_33 {
                        let h_66: number;
                        export { h_66 as h };
                        let s_33: number;
                        export { s_33 as s };
                        let l_66: number;
                        export { l_66 as l };
                    }
                    export { hsl_33 as hsl };
                    export namespace oklch_33 {
                        let l_67: number;
                        export { l_67 as l };
                        let c_33: number;
                        export { c_33 as c };
                        let h_67: number;
                        export { h_67 as h };
                    }
                    export { oklch_33 as oklch };
                    let code_7: number;
                    export { code_7 as code };
                }
                export { bright_3 as bright };
            }
            export { yellow_1 as yellow };
            export namespace blue_1 {
                let name_39: string;
                export { name_39 as name };
                let order_31: number;
                export { order_31 as order };
                export namespace normal_4 {
                    let name_40: string;
                    export { name_40 as name };
                    let hex_34: string;
                    export { hex_34 as hex };
                    export namespace rgb_34 {
                        let r_34: number;
                        export { r_34 as r };
                        let g_34: number;
                        export { g_34 as g };
                        let b_34: number;
                        export { b_34 as b };
                    }
                    export { rgb_34 as rgb };
                    export namespace hsl_34 {
                        let h_68: number;
                        export { h_68 as h };
                        let s_34: number;
                        export { s_34 as s };
                        let l_68: number;
                        export { l_68 as l };
                    }
                    export { hsl_34 as hsl };
                    export namespace oklch_34 {
                        let l_69: number;
                        export { l_69 as l };
                        let c_34: number;
                        export { c_34 as c };
                        let h_69: number;
                        export { h_69 as h };
                    }
                    export { oklch_34 as oklch };
                    let code_8: number;
                    export { code_8 as code };
                }
                export { normal_4 as normal };
                export namespace bright_4 {
                    let name_41: string;
                    export { name_41 as name };
                    let hex_35: string;
                    export { hex_35 as hex };
                    export namespace rgb_35 {
                        let r_35: number;
                        export { r_35 as r };
                        let g_35: number;
                        export { g_35 as g };
                        let b_35: number;
                        export { b_35 as b };
                    }
                    export { rgb_35 as rgb };
                    export namespace hsl_35 {
                        let h_70: number;
                        export { h_70 as h };
                        let s_35: number;
                        export { s_35 as s };
                        let l_70: number;
                        export { l_70 as l };
                    }
                    export { hsl_35 as hsl };
                    export namespace oklch_35 {
                        let l_71: number;
                        export { l_71 as l };
                        let c_35: number;
                        export { c_35 as c };
                        let h_71: number;
                        export { h_71 as h };
                    }
                    export { oklch_35 as oklch };
                    let code_9: number;
                    export { code_9 as code };
                }
                export { bright_4 as bright };
            }
            export { blue_1 as blue };
            export namespace magenta {
                let name_42: string;
                export { name_42 as name };
                let order_32: number;
                export { order_32 as order };
                export namespace normal_5 {
                    let name_43: string;
                    export { name_43 as name };
                    let hex_36: string;
                    export { hex_36 as hex };
                    export namespace rgb_36 {
                        let r_36: number;
                        export { r_36 as r };
                        let g_36: number;
                        export { g_36 as g };
                        let b_36: number;
                        export { b_36 as b };
                    }
                    export { rgb_36 as rgb };
                    export namespace hsl_36 {
                        let h_72: number;
                        export { h_72 as h };
                        let s_36: number;
                        export { s_36 as s };
                        let l_72: number;
                        export { l_72 as l };
                    }
                    export { hsl_36 as hsl };
                    export namespace oklch_36 {
                        let l_73: number;
                        export { l_73 as l };
                        let c_36: number;
                        export { c_36 as c };
                        let h_73: number;
                        export { h_73 as h };
                    }
                    export { oklch_36 as oklch };
                    let code_10: number;
                    export { code_10 as code };
                }
                export { normal_5 as normal };
                export namespace bright_5 {
                    let name_44: string;
                    export { name_44 as name };
                    let hex_37: string;
                    export { hex_37 as hex };
                    export namespace rgb_37 {
                        let r_37: number;
                        export { r_37 as r };
                        let g_37: number;
                        export { g_37 as g };
                        let b_37: number;
                        export { b_37 as b };
                    }
                    export { rgb_37 as rgb };
                    export namespace hsl_37 {
                        let h_74: number;
                        export { h_74 as h };
                        let s_37: number;
                        export { s_37 as s };
                        let l_74: number;
                        export { l_74 as l };
                    }
                    export { hsl_37 as hsl };
                    export namespace oklch_37 {
                        let l_75: number;
                        export { l_75 as l };
                        let c_37: number;
                        export { c_37 as c };
                        let h_75: number;
                        export { h_75 as h };
                    }
                    export { oklch_37 as oklch };
                    let code_11: number;
                    export { code_11 as code };
                }
                export { bright_5 as bright };
            }
            export namespace cyan {
                let name_45: string;
                export { name_45 as name };
                let order_33: number;
                export { order_33 as order };
                export namespace normal_6 {
                    let name_46: string;
                    export { name_46 as name };
                    let hex_38: string;
                    export { hex_38 as hex };
                    export namespace rgb_38 {
                        let r_38: number;
                        export { r_38 as r };
                        let g_38: number;
                        export { g_38 as g };
                        let b_38: number;
                        export { b_38 as b };
                    }
                    export { rgb_38 as rgb };
                    export namespace hsl_38 {
                        let h_76: number;
                        export { h_76 as h };
                        let s_38: number;
                        export { s_38 as s };
                        let l_76: number;
                        export { l_76 as l };
                    }
                    export { hsl_38 as hsl };
                    export namespace oklch_38 {
                        let l_77: number;
                        export { l_77 as l };
                        let c_38: number;
                        export { c_38 as c };
                        let h_77: number;
                        export { h_77 as h };
                    }
                    export { oklch_38 as oklch };
                    let code_12: number;
                    export { code_12 as code };
                }
                export { normal_6 as normal };
                export namespace bright_6 {
                    let name_47: string;
                    export { name_47 as name };
                    let hex_39: string;
                    export { hex_39 as hex };
                    export namespace rgb_39 {
                        let r_39: number;
                        export { r_39 as r };
                        let g_39: number;
                        export { g_39 as g };
                        let b_39: number;
                        export { b_39 as b };
                    }
                    export { rgb_39 as rgb };
                    export namespace hsl_39 {
                        let h_78: number;
                        export { h_78 as h };
                        let s_39: number;
                        export { s_39 as s };
                        let l_78: number;
                        export { l_78 as l };
                    }
                    export { hsl_39 as hsl };
                    export namespace oklch_39 {
                        let l_79: number;
                        export { l_79 as l };
                        let c_39: number;
                        export { c_39 as c };
                        let h_79: number;
                        export { h_79 as h };
                    }
                    export { oklch_39 as oklch };
                    let code_13: number;
                    export { code_13 as code };
                }
                export { bright_6 as bright };
            }
            export namespace white {
                let name_48: string;
                export { name_48 as name };
                let order_34: number;
                export { order_34 as order };
                export namespace normal_7 {
                    let name_49: string;
                    export { name_49 as name };
                    let hex_40: string;
                    export { hex_40 as hex };
                    export namespace rgb_40 {
                        let r_40: number;
                        export { r_40 as r };
                        let g_40: number;
                        export { g_40 as g };
                        let b_40: number;
                        export { b_40 as b };
                    }
                    export { rgb_40 as rgb };
                    export namespace hsl_40 {
                        let h_80: number;
                        export { h_80 as h };
                        let s_40: number;
                        export { s_40 as s };
                        let l_80: number;
                        export { l_80 as l };
                    }
                    export { hsl_40 as hsl };
                    export namespace oklch_40 {
                        let l_81: number;
                        export { l_81 as l };
                        let c_40: number;
                        export { c_40 as c };
                        let h_81: number;
                        export { h_81 as h };
                    }
                    export { oklch_40 as oklch };
                    let code_14: number;
                    export { code_14 as code };
                }
                export { normal_7 as normal };
                export namespace bright_7 {
                    let name_50: string;
                    export { name_50 as name };
                    let hex_41: string;
                    export { hex_41 as hex };
                    export namespace rgb_41 {
                        let r_41: number;
                        export { r_41 as r };
                        let g_41: number;
                        export { g_41 as g };
                        let b_41: number;
                        export { b_41 as b };
                    }
                    export { rgb_41 as rgb };
                    export namespace hsl_41 {
                        let h_82: number;
                        export { h_82 as h };
                        let s_41: number;
                        export { s_41 as s };
                        let l_82: number;
                        export { l_82 as l };
                    }
                    export { hsl_41 as hsl };
                    export namespace oklch_41 {
                        let l_83: number;
                        export { l_83 as l };
                        let c_41: number;
                        export { c_41 as c };
                        let h_83: number;
                        export { h_83 as h };
                    }
                    export { oklch_41 as oklch };
                    let code_15: number;
                    export { code_15 as code };
                }
                export { bright_7 as bright };
            }
        }
    }
    namespace frappe {
        let name_51: string;
        export { name_51 as name };
        let emoji_1: string;
        export { emoji_1 as emoji };
        let order_35: number;
        export { order_35 as order };
        let dark_1: boolean;
        export { dark_1 as dark };
        export namespace colors_1 {
            export namespace rosewater_1 {
                let name_52: string;
                export { name_52 as name };
                let order_36: number;
                export { order_36 as order };
                let hex_42: string;
                export { hex_42 as hex };
                export namespace rgb_42 {
                    let r_42: number;
                    export { r_42 as r };
                    let g_42: number;
                    export { g_42 as g };
                    let b_42: number;
                    export { b_42 as b };
                }
                export { rgb_42 as rgb };
                export namespace hsl_42 {
                    let h_84: number;
                    export { h_84 as h };
                    let s_42: number;
                    export { s_42 as s };
                    let l_84: number;
                    export { l_84 as l };
                }
                export { hsl_42 as hsl };
                export namespace oklch_42 {
                    let l_85: number;
                    export { l_85 as l };
                    let c_42: number;
                    export { c_42 as c };
                    let h_85: number;
                    export { h_85 as h };
                }
                export { oklch_42 as oklch };
                let accent_26: boolean;
                export { accent_26 as accent };
            }
            export { rosewater_1 as rosewater };
            export namespace flamingo_1 {
                let name_53: string;
                export { name_53 as name };
                let order_37: number;
                export { order_37 as order };
                let hex_43: string;
                export { hex_43 as hex };
                export namespace rgb_43 {
                    let r_43: number;
                    export { r_43 as r };
                    let g_43: number;
                    export { g_43 as g };
                    let b_43: number;
                    export { b_43 as b };
                }
                export { rgb_43 as rgb };
                export namespace hsl_43 {
                    let h_86: number;
                    export { h_86 as h };
                    let s_43: number;
                    export { s_43 as s };
                    let l_86: number;
                    export { l_86 as l };
                }
                export { hsl_43 as hsl };
                export namespace oklch_43 {
                    let l_87: number;
                    export { l_87 as l };
                    let c_43: number;
                    export { c_43 as c };
                    let h_87: number;
                    export { h_87 as h };
                }
                export { oklch_43 as oklch };
                let accent_27: boolean;
                export { accent_27 as accent };
            }
            export { flamingo_1 as flamingo };
            export namespace pink_1 {
                let name_54: string;
                export { name_54 as name };
                let order_38: number;
                export { order_38 as order };
                let hex_44: string;
                export { hex_44 as hex };
                export namespace rgb_44 {
                    let r_44: number;
                    export { r_44 as r };
                    let g_44: number;
                    export { g_44 as g };
                    let b_44: number;
                    export { b_44 as b };
                }
                export { rgb_44 as rgb };
                export namespace hsl_44 {
                    let h_88: number;
                    export { h_88 as h };
                    let s_44: number;
                    export { s_44 as s };
                    let l_88: number;
                    export { l_88 as l };
                }
                export { hsl_44 as hsl };
                export namespace oklch_44 {
                    let l_89: number;
                    export { l_89 as l };
                    let c_44: number;
                    export { c_44 as c };
                    let h_89: number;
                    export { h_89 as h };
                }
                export { oklch_44 as oklch };
                let accent_28: boolean;
                export { accent_28 as accent };
            }
            export { pink_1 as pink };
            export namespace mauve_1 {
                let name_55: string;
                export { name_55 as name };
                let order_39: number;
                export { order_39 as order };
                let hex_45: string;
                export { hex_45 as hex };
                export namespace rgb_45 {
                    let r_45: number;
                    export { r_45 as r };
                    let g_45: number;
                    export { g_45 as g };
                    let b_45: number;
                    export { b_45 as b };
                }
                export { rgb_45 as rgb };
                export namespace hsl_45 {
                    let h_90: number;
                    export { h_90 as h };
                    let s_45: number;
                    export { s_45 as s };
                    let l_90: number;
                    export { l_90 as l };
                }
                export { hsl_45 as hsl };
                export namespace oklch_45 {
                    let l_91: number;
                    export { l_91 as l };
                    let c_45: number;
                    export { c_45 as c };
                    let h_91: number;
                    export { h_91 as h };
                }
                export { oklch_45 as oklch };
                let accent_29: boolean;
                export { accent_29 as accent };
            }
            export { mauve_1 as mauve };
            export namespace red_2 {
                let name_56: string;
                export { name_56 as name };
                let order_40: number;
                export { order_40 as order };
                let hex_46: string;
                export { hex_46 as hex };
                export namespace rgb_46 {
                    let r_46: number;
                    export { r_46 as r };
                    let g_46: number;
                    export { g_46 as g };
                    let b_46: number;
                    export { b_46 as b };
                }
                export { rgb_46 as rgb };
                export namespace hsl_46 {
                    let h_92: number;
                    export { h_92 as h };
                    let s_46: number;
                    export { s_46 as s };
                    let l_92: number;
                    export { l_92 as l };
                }
                export { hsl_46 as hsl };
                export namespace oklch_46 {
                    let l_93: number;
                    export { l_93 as l };
                    let c_46: number;
                    export { c_46 as c };
                    let h_93: number;
                    export { h_93 as h };
                }
                export { oklch_46 as oklch };
                let accent_30: boolean;
                export { accent_30 as accent };
            }
            export { red_2 as red };
            export namespace maroon_1 {
                let name_57: string;
                export { name_57 as name };
                let order_41: number;
                export { order_41 as order };
                let hex_47: string;
                export { hex_47 as hex };
                export namespace rgb_47 {
                    let r_47: number;
                    export { r_47 as r };
                    let g_47: number;
                    export { g_47 as g };
                    let b_47: number;
                    export { b_47 as b };
                }
                export { rgb_47 as rgb };
                export namespace hsl_47 {
                    let h_94: number;
                    export { h_94 as h };
                    let s_47: number;
                    export { s_47 as s };
                    let l_94: number;
                    export { l_94 as l };
                }
                export { hsl_47 as hsl };
                export namespace oklch_47 {
                    let l_95: number;
                    export { l_95 as l };
                    let c_47: number;
                    export { c_47 as c };
                    let h_95: number;
                    export { h_95 as h };
                }
                export { oklch_47 as oklch };
                let accent_31: boolean;
                export { accent_31 as accent };
            }
            export { maroon_1 as maroon };
            export namespace peach_1 {
                let name_58: string;
                export { name_58 as name };
                let order_42: number;
                export { order_42 as order };
                let hex_48: string;
                export { hex_48 as hex };
                export namespace rgb_48 {
                    let r_48: number;
                    export { r_48 as r };
                    let g_48: number;
                    export { g_48 as g };
                    let b_48: number;
                    export { b_48 as b };
                }
                export { rgb_48 as rgb };
                export namespace hsl_48 {
                    let h_96: number;
                    export { h_96 as h };
                    let s_48: number;
                    export { s_48 as s };
                    let l_96: number;
                    export { l_96 as l };
                }
                export { hsl_48 as hsl };
                export namespace oklch_48 {
                    let l_97: number;
                    export { l_97 as l };
                    let c_48: number;
                    export { c_48 as c };
                    let h_97: number;
                    export { h_97 as h };
                }
                export { oklch_48 as oklch };
                let accent_32: boolean;
                export { accent_32 as accent };
            }
            export { peach_1 as peach };
            export namespace yellow_2 {
                let name_59: string;
                export { name_59 as name };
                let order_43: number;
                export { order_43 as order };
                let hex_49: string;
                export { hex_49 as hex };
                export namespace rgb_49 {
                    let r_49: number;
                    export { r_49 as r };
                    let g_49: number;
                    export { g_49 as g };
                    let b_49: number;
                    export { b_49 as b };
                }
                export { rgb_49 as rgb };
                export namespace hsl_49 {
                    let h_98: number;
                    export { h_98 as h };
                    let s_49: number;
                    export { s_49 as s };
                    let l_98: number;
                    export { l_98 as l };
                }
                export { hsl_49 as hsl };
                export namespace oklch_49 {
                    let l_99: number;
                    export { l_99 as l };
                    let c_49: number;
                    export { c_49 as c };
                    let h_99: number;
                    export { h_99 as h };
                }
                export { oklch_49 as oklch };
                let accent_33: boolean;
                export { accent_33 as accent };
            }
            export { yellow_2 as yellow };
            export namespace green_2 {
                let name_60: string;
                export { name_60 as name };
                let order_44: number;
                export { order_44 as order };
                let hex_50: string;
                export { hex_50 as hex };
                export namespace rgb_50 {
                    let r_50: number;
                    export { r_50 as r };
                    let g_50: number;
                    export { g_50 as g };
                    let b_50: number;
                    export { b_50 as b };
                }
                export { rgb_50 as rgb };
                export namespace hsl_50 {
                    let h_100: number;
                    export { h_100 as h };
                    let s_50: number;
                    export { s_50 as s };
                    let l_100: number;
                    export { l_100 as l };
                }
                export { hsl_50 as hsl };
                export namespace oklch_50 {
                    let l_101: number;
                    export { l_101 as l };
                    let c_50: number;
                    export { c_50 as c };
                    let h_101: number;
                    export { h_101 as h };
                }
                export { oklch_50 as oklch };
                let accent_34: boolean;
                export { accent_34 as accent };
            }
            export { green_2 as green };
            export namespace teal_1 {
                let name_61: string;
                export { name_61 as name };
                let order_45: number;
                export { order_45 as order };
                let hex_51: string;
                export { hex_51 as hex };
                export namespace rgb_51 {
                    let r_51: number;
                    export { r_51 as r };
                    let g_51: number;
                    export { g_51 as g };
                    let b_51: number;
                    export { b_51 as b };
                }
                export { rgb_51 as rgb };
                export namespace hsl_51 {
                    let h_102: number;
                    export { h_102 as h };
                    let s_51: number;
                    export { s_51 as s };
                    let l_102: number;
                    export { l_102 as l };
                }
                export { hsl_51 as hsl };
                export namespace oklch_51 {
                    let l_103: number;
                    export { l_103 as l };
                    let c_51: number;
                    export { c_51 as c };
                    let h_103: number;
                    export { h_103 as h };
                }
                export { oklch_51 as oklch };
                let accent_35: boolean;
                export { accent_35 as accent };
            }
            export { teal_1 as teal };
            export namespace sky_1 {
                let name_62: string;
                export { name_62 as name };
                let order_46: number;
                export { order_46 as order };
                let hex_52: string;
                export { hex_52 as hex };
                export namespace rgb_52 {
                    let r_52: number;
                    export { r_52 as r };
                    let g_52: number;
                    export { g_52 as g };
                    let b_52: number;
                    export { b_52 as b };
                }
                export { rgb_52 as rgb };
                export namespace hsl_52 {
                    let h_104: number;
                    export { h_104 as h };
                    let s_52: number;
                    export { s_52 as s };
                    let l_104: number;
                    export { l_104 as l };
                }
                export { hsl_52 as hsl };
                export namespace oklch_52 {
                    let l_105: number;
                    export { l_105 as l };
                    let c_52: number;
                    export { c_52 as c };
                    let h_105: number;
                    export { h_105 as h };
                }
                export { oklch_52 as oklch };
                let accent_36: boolean;
                export { accent_36 as accent };
            }
            export { sky_1 as sky };
            export namespace sapphire_1 {
                let name_63: string;
                export { name_63 as name };
                let order_47: number;
                export { order_47 as order };
                let hex_53: string;
                export { hex_53 as hex };
                export namespace rgb_53 {
                    let r_53: number;
                    export { r_53 as r };
                    let g_53: number;
                    export { g_53 as g };
                    let b_53: number;
                    export { b_53 as b };
                }
                export { rgb_53 as rgb };
                export namespace hsl_53 {
                    let h_106: number;
                    export { h_106 as h };
                    let s_53: number;
                    export { s_53 as s };
                    let l_106: number;
                    export { l_106 as l };
                }
                export { hsl_53 as hsl };
                export namespace oklch_53 {
                    let l_107: number;
                    export { l_107 as l };
                    let c_53: number;
                    export { c_53 as c };
                    let h_107: number;
                    export { h_107 as h };
                }
                export { oklch_53 as oklch };
                let accent_37: boolean;
                export { accent_37 as accent };
            }
            export { sapphire_1 as sapphire };
            export namespace blue_2 {
                let name_64: string;
                export { name_64 as name };
                let order_48: number;
                export { order_48 as order };
                let hex_54: string;
                export { hex_54 as hex };
                export namespace rgb_54 {
                    let r_54: number;
                    export { r_54 as r };
                    let g_54: number;
                    export { g_54 as g };
                    let b_54: number;
                    export { b_54 as b };
                }
                export { rgb_54 as rgb };
                export namespace hsl_54 {
                    let h_108: number;
                    export { h_108 as h };
                    let s_54: number;
                    export { s_54 as s };
                    let l_108: number;
                    export { l_108 as l };
                }
                export { hsl_54 as hsl };
                export namespace oklch_54 {
                    let l_109: number;
                    export { l_109 as l };
                    let c_54: number;
                    export { c_54 as c };
                    let h_109: number;
                    export { h_109 as h };
                }
                export { oklch_54 as oklch };
                let accent_38: boolean;
                export { accent_38 as accent };
            }
            export { blue_2 as blue };
            export namespace lavender_1 {
                let name_65: string;
                export { name_65 as name };
                let order_49: number;
                export { order_49 as order };
                let hex_55: string;
                export { hex_55 as hex };
                export namespace rgb_55 {
                    let r_55: number;
                    export { r_55 as r };
                    let g_55: number;
                    export { g_55 as g };
                    let b_55: number;
                    export { b_55 as b };
                }
                export { rgb_55 as rgb };
                export namespace hsl_55 {
                    let h_110: number;
                    export { h_110 as h };
                    let s_55: number;
                    export { s_55 as s };
                    let l_110: number;
                    export { l_110 as l };
                }
                export { hsl_55 as hsl };
                export namespace oklch_55 {
                    let l_111: number;
                    export { l_111 as l };
                    let c_55: number;
                    export { c_55 as c };
                    let h_111: number;
                    export { h_111 as h };
                }
                export { oklch_55 as oklch };
                let accent_39: boolean;
                export { accent_39 as accent };
            }
            export { lavender_1 as lavender };
            export namespace text_1 {
                let name_66: string;
                export { name_66 as name };
                let order_50: number;
                export { order_50 as order };
                let hex_56: string;
                export { hex_56 as hex };
                export namespace rgb_56 {
                    let r_56: number;
                    export { r_56 as r };
                    let g_56: number;
                    export { g_56 as g };
                    let b_56: number;
                    export { b_56 as b };
                }
                export { rgb_56 as rgb };
                export namespace hsl_56 {
                    let h_112: number;
                    export { h_112 as h };
                    let s_56: number;
                    export { s_56 as s };
                    let l_112: number;
                    export { l_112 as l };
                }
                export { hsl_56 as hsl };
                export namespace oklch_56 {
                    let l_113: number;
                    export { l_113 as l };
                    let c_56: number;
                    export { c_56 as c };
                    let h_113: number;
                    export { h_113 as h };
                }
                export { oklch_56 as oklch };
                let accent_40: boolean;
                export { accent_40 as accent };
            }
            export { text_1 as text };
            export namespace subtext1_1 {
                let name_67: string;
                export { name_67 as name };
                let order_51: number;
                export { order_51 as order };
                let hex_57: string;
                export { hex_57 as hex };
                export namespace rgb_57 {
                    let r_57: number;
                    export { r_57 as r };
                    let g_57: number;
                    export { g_57 as g };
                    let b_57: number;
                    export { b_57 as b };
                }
                export { rgb_57 as rgb };
                export namespace hsl_57 {
                    let h_114: number;
                    export { h_114 as h };
                    let s_57: number;
                    export { s_57 as s };
                    let l_114: number;
                    export { l_114 as l };
                }
                export { hsl_57 as hsl };
                export namespace oklch_57 {
                    let l_115: number;
                    export { l_115 as l };
                    let c_57: number;
                    export { c_57 as c };
                    let h_115: number;
                    export { h_115 as h };
                }
                export { oklch_57 as oklch };
                let accent_41: boolean;
                export { accent_41 as accent };
            }
            export { subtext1_1 as subtext1 };
            export namespace subtext0_1 {
                let name_68: string;
                export { name_68 as name };
                let order_52: number;
                export { order_52 as order };
                let hex_58: string;
                export { hex_58 as hex };
                export namespace rgb_58 {
                    let r_58: number;
                    export { r_58 as r };
                    let g_58: number;
                    export { g_58 as g };
                    let b_58: number;
                    export { b_58 as b };
                }
                export { rgb_58 as rgb };
                export namespace hsl_58 {
                    let h_116: number;
                    export { h_116 as h };
                    let s_58: number;
                    export { s_58 as s };
                    let l_116: number;
                    export { l_116 as l };
                }
                export { hsl_58 as hsl };
                export namespace oklch_58 {
                    let l_117: number;
                    export { l_117 as l };
                    let c_58: number;
                    export { c_58 as c };
                    let h_117: number;
                    export { h_117 as h };
                }
                export { oklch_58 as oklch };
                let accent_42: boolean;
                export { accent_42 as accent };
            }
            export { subtext0_1 as subtext0 };
            export namespace overlay2_1 {
                let name_69: string;
                export { name_69 as name };
                let order_53: number;
                export { order_53 as order };
                let hex_59: string;
                export { hex_59 as hex };
                export namespace rgb_59 {
                    let r_59: number;
                    export { r_59 as r };
                    let g_59: number;
                    export { g_59 as g };
                    let b_59: number;
                    export { b_59 as b };
                }
                export { rgb_59 as rgb };
                export namespace hsl_59 {
                    let h_118: number;
                    export { h_118 as h };
                    let s_59: number;
                    export { s_59 as s };
                    let l_118: number;
                    export { l_118 as l };
                }
                export { hsl_59 as hsl };
                export namespace oklch_59 {
                    let l_119: number;
                    export { l_119 as l };
                    let c_59: number;
                    export { c_59 as c };
                    let h_119: number;
                    export { h_119 as h };
                }
                export { oklch_59 as oklch };
                let accent_43: boolean;
                export { accent_43 as accent };
            }
            export { overlay2_1 as overlay2 };
            export namespace overlay1_1 {
                let name_70: string;
                export { name_70 as name };
                let order_54: number;
                export { order_54 as order };
                let hex_60: string;
                export { hex_60 as hex };
                export namespace rgb_60 {
                    let r_60: number;
                    export { r_60 as r };
                    let g_60: number;
                    export { g_60 as g };
                    let b_60: number;
                    export { b_60 as b };
                }
                export { rgb_60 as rgb };
                export namespace hsl_60 {
                    let h_120: number;
                    export { h_120 as h };
                    let s_60: number;
                    export { s_60 as s };
                    let l_120: number;
                    export { l_120 as l };
                }
                export { hsl_60 as hsl };
                export namespace oklch_60 {
                    let l_121: number;
                    export { l_121 as l };
                    let c_60: number;
                    export { c_60 as c };
                    let h_121: number;
                    export { h_121 as h };
                }
                export { oklch_60 as oklch };
                let accent_44: boolean;
                export { accent_44 as accent };
            }
            export { overlay1_1 as overlay1 };
            export namespace overlay0_1 {
                let name_71: string;
                export { name_71 as name };
                let order_55: number;
                export { order_55 as order };
                let hex_61: string;
                export { hex_61 as hex };
                export namespace rgb_61 {
                    let r_61: number;
                    export { r_61 as r };
                    let g_61: number;
                    export { g_61 as g };
                    let b_61: number;
                    export { b_61 as b };
                }
                export { rgb_61 as rgb };
                export namespace hsl_61 {
                    let h_122: number;
                    export { h_122 as h };
                    let s_61: number;
                    export { s_61 as s };
                    let l_122: number;
                    export { l_122 as l };
                }
                export { hsl_61 as hsl };
                export namespace oklch_61 {
                    let l_123: number;
                    export { l_123 as l };
                    let c_61: number;
                    export { c_61 as c };
                    let h_123: number;
                    export { h_123 as h };
                }
                export { oklch_61 as oklch };
                let accent_45: boolean;
                export { accent_45 as accent };
            }
            export { overlay0_1 as overlay0 };
            export namespace surface2_1 {
                let name_72: string;
                export { name_72 as name };
                let order_56: number;
                export { order_56 as order };
                let hex_62: string;
                export { hex_62 as hex };
                export namespace rgb_62 {
                    let r_62: number;
                    export { r_62 as r };
                    let g_62: number;
                    export { g_62 as g };
                    let b_62: number;
                    export { b_62 as b };
                }
                export { rgb_62 as rgb };
                export namespace hsl_62 {
                    let h_124: number;
                    export { h_124 as h };
                    let s_62: number;
                    export { s_62 as s };
                    let l_124: number;
                    export { l_124 as l };
                }
                export { hsl_62 as hsl };
                export namespace oklch_62 {
                    let l_125: number;
                    export { l_125 as l };
                    let c_62: number;
                    export { c_62 as c };
                    let h_125: number;
                    export { h_125 as h };
                }
                export { oklch_62 as oklch };
                let accent_46: boolean;
                export { accent_46 as accent };
            }
            export { surface2_1 as surface2 };
            export namespace surface1_1 {
                let name_73: string;
                export { name_73 as name };
                let order_57: number;
                export { order_57 as order };
                let hex_63: string;
                export { hex_63 as hex };
                export namespace rgb_63 {
                    let r_63: number;
                    export { r_63 as r };
                    let g_63: number;
                    export { g_63 as g };
                    let b_63: number;
                    export { b_63 as b };
                }
                export { rgb_63 as rgb };
                export namespace hsl_63 {
                    let h_126: number;
                    export { h_126 as h };
                    let s_63: number;
                    export { s_63 as s };
                    let l_126: number;
                    export { l_126 as l };
                }
                export { hsl_63 as hsl };
                export namespace oklch_63 {
                    let l_127: number;
                    export { l_127 as l };
                    let c_63: number;
                    export { c_63 as c };
                    let h_127: number;
                    export { h_127 as h };
                }
                export { oklch_63 as oklch };
                let accent_47: boolean;
                export { accent_47 as accent };
            }
            export { surface1_1 as surface1 };
            export namespace surface0_1 {
                let name_74: string;
                export { name_74 as name };
                let order_58: number;
                export { order_58 as order };
                let hex_64: string;
                export { hex_64 as hex };
                export namespace rgb_64 {
                    let r_64: number;
                    export { r_64 as r };
                    let g_64: number;
                    export { g_64 as g };
                    let b_64: number;
                    export { b_64 as b };
                }
                export { rgb_64 as rgb };
                export namespace hsl_64 {
                    let h_128: number;
                    export { h_128 as h };
                    let s_64: number;
                    export { s_64 as s };
                    let l_128: number;
                    export { l_128 as l };
                }
                export { hsl_64 as hsl };
                export namespace oklch_64 {
                    let l_129: number;
                    export { l_129 as l };
                    let c_64: number;
                    export { c_64 as c };
                    let h_129: number;
                    export { h_129 as h };
                }
                export { oklch_64 as oklch };
                let accent_48: boolean;
                export { accent_48 as accent };
            }
            export { surface0_1 as surface0 };
            export namespace base_1 {
                let name_75: string;
                export { name_75 as name };
                let order_59: number;
                export { order_59 as order };
                let hex_65: string;
                export { hex_65 as hex };
                export namespace rgb_65 {
                    let r_65: number;
                    export { r_65 as r };
                    let g_65: number;
                    export { g_65 as g };
                    let b_65: number;
                    export { b_65 as b };
                }
                export { rgb_65 as rgb };
                export namespace hsl_65 {
                    let h_130: number;
                    export { h_130 as h };
                    let s_65: number;
                    export { s_65 as s };
                    let l_130: number;
                    export { l_130 as l };
                }
                export { hsl_65 as hsl };
                export namespace oklch_65 {
                    let l_131: number;
                    export { l_131 as l };
                    let c_65: number;
                    export { c_65 as c };
                    let h_131: number;
                    export { h_131 as h };
                }
                export { oklch_65 as oklch };
                let accent_49: boolean;
                export { accent_49 as accent };
            }
            export { base_1 as base };
            export namespace mantle_1 {
                let name_76: string;
                export { name_76 as name };
                let order_60: number;
                export { order_60 as order };
                let hex_66: string;
                export { hex_66 as hex };
                export namespace rgb_66 {
                    let r_66: number;
                    export { r_66 as r };
                    let g_66: number;
                    export { g_66 as g };
                    let b_66: number;
                    export { b_66 as b };
                }
                export { rgb_66 as rgb };
                export namespace hsl_66 {
                    let h_132: number;
                    export { h_132 as h };
                    let s_66: number;
                    export { s_66 as s };
                    let l_132: number;
                    export { l_132 as l };
                }
                export { hsl_66 as hsl };
                export namespace oklch_66 {
                    let l_133: number;
                    export { l_133 as l };
                    let c_66: number;
                    export { c_66 as c };
                    let h_133: number;
                    export { h_133 as h };
                }
                export { oklch_66 as oklch };
                let accent_50: boolean;
                export { accent_50 as accent };
            }
            export { mantle_1 as mantle };
            export namespace crust_1 {
                let name_77: string;
                export { name_77 as name };
                let order_61: number;
                export { order_61 as order };
                let hex_67: string;
                export { hex_67 as hex };
                export namespace rgb_67 {
                    let r_67: number;
                    export { r_67 as r };
                    let g_67: number;
                    export { g_67 as g };
                    let b_67: number;
                    export { b_67 as b };
                }
                export { rgb_67 as rgb };
                export namespace hsl_67 {
                    let h_134: number;
                    export { h_134 as h };
                    let s_67: number;
                    export { s_67 as s };
                    let l_134: number;
                    export { l_134 as l };
                }
                export { hsl_67 as hsl };
                export namespace oklch_67 {
                    let l_135: number;
                    export { l_135 as l };
                    let c_67: number;
                    export { c_67 as c };
                    let h_135: number;
                    export { h_135 as h };
                }
                export { oklch_67 as oklch };
                let accent_51: boolean;
                export { accent_51 as accent };
            }
            export { crust_1 as crust };
        }
        export { colors_1 as colors };
        export namespace ansiColors_1 {
            export namespace black_1 {
                let name_78: string;
                export { name_78 as name };
                let order_62: number;
                export { order_62 as order };
                export namespace normal_8 {
                    let name_79: string;
                    export { name_79 as name };
                    let hex_68: string;
                    export { hex_68 as hex };
                    export namespace rgb_68 {
                        let r_68: number;
                        export { r_68 as r };
                        let g_68: number;
                        export { g_68 as g };
                        let b_68: number;
                        export { b_68 as b };
                    }
                    export { rgb_68 as rgb };
                    export namespace hsl_68 {
                        let h_136: number;
                        export { h_136 as h };
                        let s_68: number;
                        export { s_68 as s };
                        let l_136: number;
                        export { l_136 as l };
                    }
                    export { hsl_68 as hsl };
                    export namespace oklch_68 {
                        let l_137: number;
                        export { l_137 as l };
                        let c_68: number;
                        export { c_68 as c };
                        let h_137: number;
                        export { h_137 as h };
                    }
                    export { oklch_68 as oklch };
                    let code_16: number;
                    export { code_16 as code };
                }
                export { normal_8 as normal };
                export namespace bright_8 {
                    let name_80: string;
                    export { name_80 as name };
                    let hex_69: string;
                    export { hex_69 as hex };
                    export namespace rgb_69 {
                        let r_69: number;
                        export { r_69 as r };
                        let g_69: number;
                        export { g_69 as g };
                        let b_69: number;
                        export { b_69 as b };
                    }
                    export { rgb_69 as rgb };
                    export namespace hsl_69 {
                        let h_138: number;
                        export { h_138 as h };
                        let s_69: number;
                        export { s_69 as s };
                        let l_138: number;
                        export { l_138 as l };
                    }
                    export { hsl_69 as hsl };
                    export namespace oklch_69 {
                        let l_139: number;
                        export { l_139 as l };
                        let c_69: number;
                        export { c_69 as c };
                        let h_139: number;
                        export { h_139 as h };
                    }
                    export { oklch_69 as oklch };
                    let code_17: number;
                    export { code_17 as code };
                }
                export { bright_8 as bright };
            }
            export { black_1 as black };
            export namespace red_3 {
                let name_81: string;
                export { name_81 as name };
                let order_63: number;
                export { order_63 as order };
                export namespace normal_9 {
                    let name_82: string;
                    export { name_82 as name };
                    let hex_70: string;
                    export { hex_70 as hex };
                    export namespace rgb_70 {
                        let r_70: number;
                        export { r_70 as r };
                        let g_70: number;
                        export { g_70 as g };
                        let b_70: number;
                        export { b_70 as b };
                    }
                    export { rgb_70 as rgb };
                    export namespace hsl_70 {
                        let h_140: number;
                        export { h_140 as h };
                        let s_70: number;
                        export { s_70 as s };
                        let l_140: number;
                        export { l_140 as l };
                    }
                    export { hsl_70 as hsl };
                    export namespace oklch_70 {
                        let l_141: number;
                        export { l_141 as l };
                        let c_70: number;
                        export { c_70 as c };
                        let h_141: number;
                        export { h_141 as h };
                    }
                    export { oklch_70 as oklch };
                    let code_18: number;
                    export { code_18 as code };
                }
                export { normal_9 as normal };
                export namespace bright_9 {
                    let name_83: string;
                    export { name_83 as name };
                    let hex_71: string;
                    export { hex_71 as hex };
                    export namespace rgb_71 {
                        let r_71: number;
                        export { r_71 as r };
                        let g_71: number;
                        export { g_71 as g };
                        let b_71: number;
                        export { b_71 as b };
                    }
                    export { rgb_71 as rgb };
                    export namespace hsl_71 {
                        let h_142: number;
                        export { h_142 as h };
                        let s_71: number;
                        export { s_71 as s };
                        let l_142: number;
                        export { l_142 as l };
                    }
                    export { hsl_71 as hsl };
                    export namespace oklch_71 {
                        let l_143: number;
                        export { l_143 as l };
                        let c_71: number;
                        export { c_71 as c };
                        let h_143: number;
                        export { h_143 as h };
                    }
                    export { oklch_71 as oklch };
                    let code_19: number;
                    export { code_19 as code };
                }
                export { bright_9 as bright };
            }
            export { red_3 as red };
            export namespace green_3 {
                let name_84: string;
                export { name_84 as name };
                let order_64: number;
                export { order_64 as order };
                export namespace normal_10 {
                    let name_85: string;
                    export { name_85 as name };
                    let hex_72: string;
                    export { hex_72 as hex };
                    export namespace rgb_72 {
                        let r_72: number;
                        export { r_72 as r };
                        let g_72: number;
                        export { g_72 as g };
                        let b_72: number;
                        export { b_72 as b };
                    }
                    export { rgb_72 as rgb };
                    export namespace hsl_72 {
                        let h_144: number;
                        export { h_144 as h };
                        let s_72: number;
                        export { s_72 as s };
                        let l_144: number;
                        export { l_144 as l };
                    }
                    export { hsl_72 as hsl };
                    export namespace oklch_72 {
                        let l_145: number;
                        export { l_145 as l };
                        let c_72: number;
                        export { c_72 as c };
                        let h_145: number;
                        export { h_145 as h };
                    }
                    export { oklch_72 as oklch };
                    let code_20: number;
                    export { code_20 as code };
                }
                export { normal_10 as normal };
                export namespace bright_10 {
                    let name_86: string;
                    export { name_86 as name };
                    let hex_73: string;
                    export { hex_73 as hex };
                    export namespace rgb_73 {
                        let r_73: number;
                        export { r_73 as r };
                        let g_73: number;
                        export { g_73 as g };
                        let b_73: number;
                        export { b_73 as b };
                    }
                    export { rgb_73 as rgb };
                    export namespace hsl_73 {
                        let h_146: number;
                        export { h_146 as h };
                        let s_73: number;
                        export { s_73 as s };
                        let l_146: number;
                        export { l_146 as l };
                    }
                    export { hsl_73 as hsl };
                    export namespace oklch_73 {
                        let l_147: number;
                        export { l_147 as l };
                        let c_73: number;
                        export { c_73 as c };
                        let h_147: number;
                        export { h_147 as h };
                    }
                    export { oklch_73 as oklch };
                    let code_21: number;
                    export { code_21 as code };
                }
                export { bright_10 as bright };
            }
            export { green_3 as green };
            export namespace yellow_3 {
                let name_87: string;
                export { name_87 as name };
                let order_65: number;
                export { order_65 as order };
                export namespace normal_11 {
                    let name_88: string;
                    export { name_88 as name };
                    let hex_74: string;
                    export { hex_74 as hex };
                    export namespace rgb_74 {
                        let r_74: number;
                        export { r_74 as r };
                        let g_74: number;
                        export { g_74 as g };
                        let b_74: number;
                        export { b_74 as b };
                    }
                    export { rgb_74 as rgb };
                    export namespace hsl_74 {
                        let h_148: number;
                        export { h_148 as h };
                        let s_74: number;
                        export { s_74 as s };
                        let l_148: number;
                        export { l_148 as l };
                    }
                    export { hsl_74 as hsl };
                    export namespace oklch_74 {
                        let l_149: number;
                        export { l_149 as l };
                        let c_74: number;
                        export { c_74 as c };
                        let h_149: number;
                        export { h_149 as h };
                    }
                    export { oklch_74 as oklch };
                    let code_22: number;
                    export { code_22 as code };
                }
                export { normal_11 as normal };
                export namespace bright_11 {
                    let name_89: string;
                    export { name_89 as name };
                    let hex_75: string;
                    export { hex_75 as hex };
                    export namespace rgb_75 {
                        let r_75: number;
                        export { r_75 as r };
                        let g_75: number;
                        export { g_75 as g };
                        let b_75: number;
                        export { b_75 as b };
                    }
                    export { rgb_75 as rgb };
                    export namespace hsl_75 {
                        let h_150: number;
                        export { h_150 as h };
                        let s_75: number;
                        export { s_75 as s };
                        let l_150: number;
                        export { l_150 as l };
                    }
                    export { hsl_75 as hsl };
                    export namespace oklch_75 {
                        let l_151: number;
                        export { l_151 as l };
                        let c_75: number;
                        export { c_75 as c };
                        let h_151: number;
                        export { h_151 as h };
                    }
                    export { oklch_75 as oklch };
                    let code_23: number;
                    export { code_23 as code };
                }
                export { bright_11 as bright };
            }
            export { yellow_3 as yellow };
            export namespace blue_3 {
                let name_90: string;
                export { name_90 as name };
                let order_66: number;
                export { order_66 as order };
                export namespace normal_12 {
                    let name_91: string;
                    export { name_91 as name };
                    let hex_76: string;
                    export { hex_76 as hex };
                    export namespace rgb_76 {
                        let r_76: number;
                        export { r_76 as r };
                        let g_76: number;
                        export { g_76 as g };
                        let b_76: number;
                        export { b_76 as b };
                    }
                    export { rgb_76 as rgb };
                    export namespace hsl_76 {
                        let h_152: number;
                        export { h_152 as h };
                        let s_76: number;
                        export { s_76 as s };
                        let l_152: number;
                        export { l_152 as l };
                    }
                    export { hsl_76 as hsl };
                    export namespace oklch_76 {
                        let l_153: number;
                        export { l_153 as l };
                        let c_76: number;
                        export { c_76 as c };
                        let h_153: number;
                        export { h_153 as h };
                    }
                    export { oklch_76 as oklch };
                    let code_24: number;
                    export { code_24 as code };
                }
                export { normal_12 as normal };
                export namespace bright_12 {
                    let name_92: string;
                    export { name_92 as name };
                    let hex_77: string;
                    export { hex_77 as hex };
                    export namespace rgb_77 {
                        let r_77: number;
                        export { r_77 as r };
                        let g_77: number;
                        export { g_77 as g };
                        let b_77: number;
                        export { b_77 as b };
                    }
                    export { rgb_77 as rgb };
                    export namespace hsl_77 {
                        let h_154: number;
                        export { h_154 as h };
                        let s_77: number;
                        export { s_77 as s };
                        let l_154: number;
                        export { l_154 as l };
                    }
                    export { hsl_77 as hsl };
                    export namespace oklch_77 {
                        let l_155: number;
                        export { l_155 as l };
                        let c_77: number;
                        export { c_77 as c };
                        let h_155: number;
                        export { h_155 as h };
                    }
                    export { oklch_77 as oklch };
                    let code_25: number;
                    export { code_25 as code };
                }
                export { bright_12 as bright };
            }
            export { blue_3 as blue };
            export namespace magenta_1 {
                let name_93: string;
                export { name_93 as name };
                let order_67: number;
                export { order_67 as order };
                export namespace normal_13 {
                    let name_94: string;
                    export { name_94 as name };
                    let hex_78: string;
                    export { hex_78 as hex };
                    export namespace rgb_78 {
                        let r_78: number;
                        export { r_78 as r };
                        let g_78: number;
                        export { g_78 as g };
                        let b_78: number;
                        export { b_78 as b };
                    }
                    export { rgb_78 as rgb };
                    export namespace hsl_78 {
                        let h_156: number;
                        export { h_156 as h };
                        let s_78: number;
                        export { s_78 as s };
                        let l_156: number;
                        export { l_156 as l };
                    }
                    export { hsl_78 as hsl };
                    export namespace oklch_78 {
                        let l_157: number;
                        export { l_157 as l };
                        let c_78: number;
                        export { c_78 as c };
                        let h_157: number;
                        export { h_157 as h };
                    }
                    export { oklch_78 as oklch };
                    let code_26: number;
                    export { code_26 as code };
                }
                export { normal_13 as normal };
                export namespace bright_13 {
                    let name_95: string;
                    export { name_95 as name };
                    let hex_79: string;
                    export { hex_79 as hex };
                    export namespace rgb_79 {
                        let r_79: number;
                        export { r_79 as r };
                        let g_79: number;
                        export { g_79 as g };
                        let b_79: number;
                        export { b_79 as b };
                    }
                    export { rgb_79 as rgb };
                    export namespace hsl_79 {
                        let h_158: number;
                        export { h_158 as h };
                        let s_79: number;
                        export { s_79 as s };
                        let l_158: number;
                        export { l_158 as l };
                    }
                    export { hsl_79 as hsl };
                    export namespace oklch_79 {
                        let l_159: number;
                        export { l_159 as l };
                        let c_79: number;
                        export { c_79 as c };
                        let h_159: number;
                        export { h_159 as h };
                    }
                    export { oklch_79 as oklch };
                    let code_27: number;
                    export { code_27 as code };
                }
                export { bright_13 as bright };
            }
            export { magenta_1 as magenta };
            export namespace cyan_1 {
                let name_96: string;
                export { name_96 as name };
                let order_68: number;
                export { order_68 as order };
                export namespace normal_14 {
                    let name_97: string;
                    export { name_97 as name };
                    let hex_80: string;
                    export { hex_80 as hex };
                    export namespace rgb_80 {
                        let r_80: number;
                        export { r_80 as r };
                        let g_80: number;
                        export { g_80 as g };
                        let b_80: number;
                        export { b_80 as b };
                    }
                    export { rgb_80 as rgb };
                    export namespace hsl_80 {
                        let h_160: number;
                        export { h_160 as h };
                        let s_80: number;
                        export { s_80 as s };
                        let l_160: number;
                        export { l_160 as l };
                    }
                    export { hsl_80 as hsl };
                    export namespace oklch_80 {
                        let l_161: number;
                        export { l_161 as l };
                        let c_80: number;
                        export { c_80 as c };
                        let h_161: number;
                        export { h_161 as h };
                    }
                    export { oklch_80 as oklch };
                    let code_28: number;
                    export { code_28 as code };
                }
                export { normal_14 as normal };
                export namespace bright_14 {
                    let name_98: string;
                    export { name_98 as name };
                    let hex_81: string;
                    export { hex_81 as hex };
                    export namespace rgb_81 {
                        let r_81: number;
                        export { r_81 as r };
                        let g_81: number;
                        export { g_81 as g };
                        let b_81: number;
                        export { b_81 as b };
                    }
                    export { rgb_81 as rgb };
                    export namespace hsl_81 {
                        let h_162: number;
                        export { h_162 as h };
                        let s_81: number;
                        export { s_81 as s };
                        let l_162: number;
                        export { l_162 as l };
                    }
                    export { hsl_81 as hsl };
                    export namespace oklch_81 {
                        let l_163: number;
                        export { l_163 as l };
                        let c_81: number;
                        export { c_81 as c };
                        let h_163: number;
                        export { h_163 as h };
                    }
                    export { oklch_81 as oklch };
                    let code_29: number;
                    export { code_29 as code };
                }
                export { bright_14 as bright };
            }
            export { cyan_1 as cyan };
            export namespace white_1 {
                let name_99: string;
                export { name_99 as name };
                let order_69: number;
                export { order_69 as order };
                export namespace normal_15 {
                    let name_100: string;
                    export { name_100 as name };
                    let hex_82: string;
                    export { hex_82 as hex };
                    export namespace rgb_82 {
                        let r_82: number;
                        export { r_82 as r };
                        let g_82: number;
                        export { g_82 as g };
                        let b_82: number;
                        export { b_82 as b };
                    }
                    export { rgb_82 as rgb };
                    export namespace hsl_82 {
                        let h_164: number;
                        export { h_164 as h };
                        let s_82: number;
                        export { s_82 as s };
                        let l_164: number;
                        export { l_164 as l };
                    }
                    export { hsl_82 as hsl };
                    export namespace oklch_82 {
                        let l_165: number;
                        export { l_165 as l };
                        let c_82: number;
                        export { c_82 as c };
                        let h_165: number;
                        export { h_165 as h };
                    }
                    export { oklch_82 as oklch };
                    let code_30: number;
                    export { code_30 as code };
                }
                export { normal_15 as normal };
                export namespace bright_15 {
                    let name_101: string;
                    export { name_101 as name };
                    let hex_83: string;
                    export { hex_83 as hex };
                    export namespace rgb_83 {
                        let r_83: number;
                        export { r_83 as r };
                        let g_83: number;
                        export { g_83 as g };
                        let b_83: number;
                        export { b_83 as b };
                    }
                    export { rgb_83 as rgb };
                    export namespace hsl_83 {
                        let h_166: number;
                        export { h_166 as h };
                        let s_83: number;
                        export { s_83 as s };
                        let l_166: number;
                        export { l_166 as l };
                    }
                    export { hsl_83 as hsl };
                    export namespace oklch_83 {
                        let l_167: number;
                        export { l_167 as l };
                        let c_83: number;
                        export { c_83 as c };
                        let h_167: number;
                        export { h_167 as h };
                    }
                    export { oklch_83 as oklch };
                    let code_31: number;
                    export { code_31 as code };
                }
                export { bright_15 as bright };
            }
            export { white_1 as white };
        }
        export { ansiColors_1 as ansiColors };
    }
    namespace macchiato {
        let name_102: string;
        export { name_102 as name };
        let emoji_2: string;
        export { emoji_2 as emoji };
        let order_70: number;
        export { order_70 as order };
        let dark_2: boolean;
        export { dark_2 as dark };
        export namespace colors_2 {
            export namespace rosewater_2 {
                let name_103: string;
                export { name_103 as name };
                let order_71: number;
                export { order_71 as order };
                let hex_84: string;
                export { hex_84 as hex };
                export namespace rgb_84 {
                    let r_84: number;
                    export { r_84 as r };
                    let g_84: number;
                    export { g_84 as g };
                    let b_84: number;
                    export { b_84 as b };
                }
                export { rgb_84 as rgb };
                export namespace hsl_84 {
                    let h_168: number;
                    export { h_168 as h };
                    let s_84: number;
                    export { s_84 as s };
                    let l_168: number;
                    export { l_168 as l };
                }
                export { hsl_84 as hsl };
                export namespace oklch_84 {
                    let l_169: number;
                    export { l_169 as l };
                    let c_84: number;
                    export { c_84 as c };
                    let h_169: number;
                    export { h_169 as h };
                }
                export { oklch_84 as oklch };
                let accent_52: boolean;
                export { accent_52 as accent };
            }
            export { rosewater_2 as rosewater };
            export namespace flamingo_2 {
                let name_104: string;
                export { name_104 as name };
                let order_72: number;
                export { order_72 as order };
                let hex_85: string;
                export { hex_85 as hex };
                export namespace rgb_85 {
                    let r_85: number;
                    export { r_85 as r };
                    let g_85: number;
                    export { g_85 as g };
                    let b_85: number;
                    export { b_85 as b };
                }
                export { rgb_85 as rgb };
                export namespace hsl_85 {
                    let h_170: number;
                    export { h_170 as h };
                    let s_85: number;
                    export { s_85 as s };
                    let l_170: number;
                    export { l_170 as l };
                }
                export { hsl_85 as hsl };
                export namespace oklch_85 {
                    let l_171: number;
                    export { l_171 as l };
                    let c_85: number;
                    export { c_85 as c };
                    let h_171: number;
                    export { h_171 as h };
                }
                export { oklch_85 as oklch };
                let accent_53: boolean;
                export { accent_53 as accent };
            }
            export { flamingo_2 as flamingo };
            export namespace pink_2 {
                let name_105: string;
                export { name_105 as name };
                let order_73: number;
                export { order_73 as order };
                let hex_86: string;
                export { hex_86 as hex };
                export namespace rgb_86 {
                    let r_86: number;
                    export { r_86 as r };
                    let g_86: number;
                    export { g_86 as g };
                    let b_86: number;
                    export { b_86 as b };
                }
                export { rgb_86 as rgb };
                export namespace hsl_86 {
                    let h_172: number;
                    export { h_172 as h };
                    let s_86: number;
                    export { s_86 as s };
                    let l_172: number;
                    export { l_172 as l };
                }
                export { hsl_86 as hsl };
                export namespace oklch_86 {
                    let l_173: number;
                    export { l_173 as l };
                    let c_86: number;
                    export { c_86 as c };
                    let h_173: number;
                    export { h_173 as h };
                }
                export { oklch_86 as oklch };
                let accent_54: boolean;
                export { accent_54 as accent };
            }
            export { pink_2 as pink };
            export namespace mauve_2 {
                let name_106: string;
                export { name_106 as name };
                let order_74: number;
                export { order_74 as order };
                let hex_87: string;
                export { hex_87 as hex };
                export namespace rgb_87 {
                    let r_87: number;
                    export { r_87 as r };
                    let g_87: number;
                    export { g_87 as g };
                    let b_87: number;
                    export { b_87 as b };
                }
                export { rgb_87 as rgb };
                export namespace hsl_87 {
                    let h_174: number;
                    export { h_174 as h };
                    let s_87: number;
                    export { s_87 as s };
                    let l_174: number;
                    export { l_174 as l };
                }
                export { hsl_87 as hsl };
                export namespace oklch_87 {
                    let l_175: number;
                    export { l_175 as l };
                    let c_87: number;
                    export { c_87 as c };
                    let h_175: number;
                    export { h_175 as h };
                }
                export { oklch_87 as oklch };
                let accent_55: boolean;
                export { accent_55 as accent };
            }
            export { mauve_2 as mauve };
            export namespace red_4 {
                let name_107: string;
                export { name_107 as name };
                let order_75: number;
                export { order_75 as order };
                let hex_88: string;
                export { hex_88 as hex };
                export namespace rgb_88 {
                    let r_88: number;
                    export { r_88 as r };
                    let g_88: number;
                    export { g_88 as g };
                    let b_88: number;
                    export { b_88 as b };
                }
                export { rgb_88 as rgb };
                export namespace hsl_88 {
                    let h_176: number;
                    export { h_176 as h };
                    let s_88: number;
                    export { s_88 as s };
                    let l_176: number;
                    export { l_176 as l };
                }
                export { hsl_88 as hsl };
                export namespace oklch_88 {
                    let l_177: number;
                    export { l_177 as l };
                    let c_88: number;
                    export { c_88 as c };
                    let h_177: number;
                    export { h_177 as h };
                }
                export { oklch_88 as oklch };
                let accent_56: boolean;
                export { accent_56 as accent };
            }
            export { red_4 as red };
            export namespace maroon_2 {
                let name_108: string;
                export { name_108 as name };
                let order_76: number;
                export { order_76 as order };
                let hex_89: string;
                export { hex_89 as hex };
                export namespace rgb_89 {
                    let r_89: number;
                    export { r_89 as r };
                    let g_89: number;
                    export { g_89 as g };
                    let b_89: number;
                    export { b_89 as b };
                }
                export { rgb_89 as rgb };
                export namespace hsl_89 {
                    let h_178: number;
                    export { h_178 as h };
                    let s_89: number;
                    export { s_89 as s };
                    let l_178: number;
                    export { l_178 as l };
                }
                export { hsl_89 as hsl };
                export namespace oklch_89 {
                    let l_179: number;
                    export { l_179 as l };
                    let c_89: number;
                    export { c_89 as c };
                    let h_179: number;
                    export { h_179 as h };
                }
                export { oklch_89 as oklch };
                let accent_57: boolean;
                export { accent_57 as accent };
            }
            export { maroon_2 as maroon };
            export namespace peach_2 {
                let name_109: string;
                export { name_109 as name };
                let order_77: number;
                export { order_77 as order };
                let hex_90: string;
                export { hex_90 as hex };
                export namespace rgb_90 {
                    let r_90: number;
                    export { r_90 as r };
                    let g_90: number;
                    export { g_90 as g };
                    let b_90: number;
                    export { b_90 as b };
                }
                export { rgb_90 as rgb };
                export namespace hsl_90 {
                    let h_180: number;
                    export { h_180 as h };
                    let s_90: number;
                    export { s_90 as s };
                    let l_180: number;
                    export { l_180 as l };
                }
                export { hsl_90 as hsl };
                export namespace oklch_90 {
                    let l_181: number;
                    export { l_181 as l };
                    let c_90: number;
                    export { c_90 as c };
                    let h_181: number;
                    export { h_181 as h };
                }
                export { oklch_90 as oklch };
                let accent_58: boolean;
                export { accent_58 as accent };
            }
            export { peach_2 as peach };
            export namespace yellow_4 {
                let name_110: string;
                export { name_110 as name };
                let order_78: number;
                export { order_78 as order };
                let hex_91: string;
                export { hex_91 as hex };
                export namespace rgb_91 {
                    let r_91: number;
                    export { r_91 as r };
                    let g_91: number;
                    export { g_91 as g };
                    let b_91: number;
                    export { b_91 as b };
                }
                export { rgb_91 as rgb };
                export namespace hsl_91 {
                    let h_182: number;
                    export { h_182 as h };
                    let s_91: number;
                    export { s_91 as s };
                    let l_182: number;
                    export { l_182 as l };
                }
                export { hsl_91 as hsl };
                export namespace oklch_91 {
                    let l_183: number;
                    export { l_183 as l };
                    let c_91: number;
                    export { c_91 as c };
                    let h_183: number;
                    export { h_183 as h };
                }
                export { oklch_91 as oklch };
                let accent_59: boolean;
                export { accent_59 as accent };
            }
            export { yellow_4 as yellow };
            export namespace green_4 {
                let name_111: string;
                export { name_111 as name };
                let order_79: number;
                export { order_79 as order };
                let hex_92: string;
                export { hex_92 as hex };
                export namespace rgb_92 {
                    let r_92: number;
                    export { r_92 as r };
                    let g_92: number;
                    export { g_92 as g };
                    let b_92: number;
                    export { b_92 as b };
                }
                export { rgb_92 as rgb };
                export namespace hsl_92 {
                    let h_184: number;
                    export { h_184 as h };
                    let s_92: number;
                    export { s_92 as s };
                    let l_184: number;
                    export { l_184 as l };
                }
                export { hsl_92 as hsl };
                export namespace oklch_92 {
                    let l_185: number;
                    export { l_185 as l };
                    let c_92: number;
                    export { c_92 as c };
                    let h_185: number;
                    export { h_185 as h };
                }
                export { oklch_92 as oklch };
                let accent_60: boolean;
                export { accent_60 as accent };
            }
            export { green_4 as green };
            export namespace teal_2 {
                let name_112: string;
                export { name_112 as name };
                let order_80: number;
                export { order_80 as order };
                let hex_93: string;
                export { hex_93 as hex };
                export namespace rgb_93 {
                    let r_93: number;
                    export { r_93 as r };
                    let g_93: number;
                    export { g_93 as g };
                    let b_93: number;
                    export { b_93 as b };
                }
                export { rgb_93 as rgb };
                export namespace hsl_93 {
                    let h_186: number;
                    export { h_186 as h };
                    let s_93: number;
                    export { s_93 as s };
                    let l_186: number;
                    export { l_186 as l };
                }
                export { hsl_93 as hsl };
                export namespace oklch_93 {
                    let l_187: number;
                    export { l_187 as l };
                    let c_93: number;
                    export { c_93 as c };
                    let h_187: number;
                    export { h_187 as h };
                }
                export { oklch_93 as oklch };
                let accent_61: boolean;
                export { accent_61 as accent };
            }
            export { teal_2 as teal };
            export namespace sky_2 {
                let name_113: string;
                export { name_113 as name };
                let order_81: number;
                export { order_81 as order };
                let hex_94: string;
                export { hex_94 as hex };
                export namespace rgb_94 {
                    let r_94: number;
                    export { r_94 as r };
                    let g_94: number;
                    export { g_94 as g };
                    let b_94: number;
                    export { b_94 as b };
                }
                export { rgb_94 as rgb };
                export namespace hsl_94 {
                    let h_188: number;
                    export { h_188 as h };
                    let s_94: number;
                    export { s_94 as s };
                    let l_188: number;
                    export { l_188 as l };
                }
                export { hsl_94 as hsl };
                export namespace oklch_94 {
                    let l_189: number;
                    export { l_189 as l };
                    let c_94: number;
                    export { c_94 as c };
                    let h_189: number;
                    export { h_189 as h };
                }
                export { oklch_94 as oklch };
                let accent_62: boolean;
                export { accent_62 as accent };
            }
            export { sky_2 as sky };
            export namespace sapphire_2 {
                let name_114: string;
                export { name_114 as name };
                let order_82: number;
                export { order_82 as order };
                let hex_95: string;
                export { hex_95 as hex };
                export namespace rgb_95 {
                    let r_95: number;
                    export { r_95 as r };
                    let g_95: number;
                    export { g_95 as g };
                    let b_95: number;
                    export { b_95 as b };
                }
                export { rgb_95 as rgb };
                export namespace hsl_95 {
                    let h_190: number;
                    export { h_190 as h };
                    let s_95: number;
                    export { s_95 as s };
                    let l_190: number;
                    export { l_190 as l };
                }
                export { hsl_95 as hsl };
                export namespace oklch_95 {
                    let l_191: number;
                    export { l_191 as l };
                    let c_95: number;
                    export { c_95 as c };
                    let h_191: number;
                    export { h_191 as h };
                }
                export { oklch_95 as oklch };
                let accent_63: boolean;
                export { accent_63 as accent };
            }
            export { sapphire_2 as sapphire };
            export namespace blue_4 {
                let name_115: string;
                export { name_115 as name };
                let order_83: number;
                export { order_83 as order };
                let hex_96: string;
                export { hex_96 as hex };
                export namespace rgb_96 {
                    let r_96: number;
                    export { r_96 as r };
                    let g_96: number;
                    export { g_96 as g };
                    let b_96: number;
                    export { b_96 as b };
                }
                export { rgb_96 as rgb };
                export namespace hsl_96 {
                    let h_192: number;
                    export { h_192 as h };
                    let s_96: number;
                    export { s_96 as s };
                    let l_192: number;
                    export { l_192 as l };
                }
                export { hsl_96 as hsl };
                export namespace oklch_96 {
                    let l_193: number;
                    export { l_193 as l };
                    let c_96: number;
                    export { c_96 as c };
                    let h_193: number;
                    export { h_193 as h };
                }
                export { oklch_96 as oklch };
                let accent_64: boolean;
                export { accent_64 as accent };
            }
            export { blue_4 as blue };
            export namespace lavender_2 {
                let name_116: string;
                export { name_116 as name };
                let order_84: number;
                export { order_84 as order };
                let hex_97: string;
                export { hex_97 as hex };
                export namespace rgb_97 {
                    let r_97: number;
                    export { r_97 as r };
                    let g_97: number;
                    export { g_97 as g };
                    let b_97: number;
                    export { b_97 as b };
                }
                export { rgb_97 as rgb };
                export namespace hsl_97 {
                    let h_194: number;
                    export { h_194 as h };
                    let s_97: number;
                    export { s_97 as s };
                    let l_194: number;
                    export { l_194 as l };
                }
                export { hsl_97 as hsl };
                export namespace oklch_97 {
                    let l_195: number;
                    export { l_195 as l };
                    let c_97: number;
                    export { c_97 as c };
                    let h_195: number;
                    export { h_195 as h };
                }
                export { oklch_97 as oklch };
                let accent_65: boolean;
                export { accent_65 as accent };
            }
            export { lavender_2 as lavender };
            export namespace text_2 {
                let name_117: string;
                export { name_117 as name };
                let order_85: number;
                export { order_85 as order };
                let hex_98: string;
                export { hex_98 as hex };
                export namespace rgb_98 {
                    let r_98: number;
                    export { r_98 as r };
                    let g_98: number;
                    export { g_98 as g };
                    let b_98: number;
                    export { b_98 as b };
                }
                export { rgb_98 as rgb };
                export namespace hsl_98 {
                    let h_196: number;
                    export { h_196 as h };
                    let s_98: number;
                    export { s_98 as s };
                    let l_196: number;
                    export { l_196 as l };
                }
                export { hsl_98 as hsl };
                export namespace oklch_98 {
                    let l_197: number;
                    export { l_197 as l };
                    let c_98: number;
                    export { c_98 as c };
                    let h_197: number;
                    export { h_197 as h };
                }
                export { oklch_98 as oklch };
                let accent_66: boolean;
                export { accent_66 as accent };
            }
            export { text_2 as text };
            export namespace subtext1_2 {
                let name_118: string;
                export { name_118 as name };
                let order_86: number;
                export { order_86 as order };
                let hex_99: string;
                export { hex_99 as hex };
                export namespace rgb_99 {
                    let r_99: number;
                    export { r_99 as r };
                    let g_99: number;
                    export { g_99 as g };
                    let b_99: number;
                    export { b_99 as b };
                }
                export { rgb_99 as rgb };
                export namespace hsl_99 {
                    let h_198: number;
                    export { h_198 as h };
                    let s_99: number;
                    export { s_99 as s };
                    let l_198: number;
                    export { l_198 as l };
                }
                export { hsl_99 as hsl };
                export namespace oklch_99 {
                    let l_199: number;
                    export { l_199 as l };
                    let c_99: number;
                    export { c_99 as c };
                    let h_199: number;
                    export { h_199 as h };
                }
                export { oklch_99 as oklch };
                let accent_67: boolean;
                export { accent_67 as accent };
            }
            export { subtext1_2 as subtext1 };
            export namespace subtext0_2 {
                let name_119: string;
                export { name_119 as name };
                let order_87: number;
                export { order_87 as order };
                let hex_100: string;
                export { hex_100 as hex };
                export namespace rgb_100 {
                    let r_100: number;
                    export { r_100 as r };
                    let g_100: number;
                    export { g_100 as g };
                    let b_100: number;
                    export { b_100 as b };
                }
                export { rgb_100 as rgb };
                export namespace hsl_100 {
                    let h_200: number;
                    export { h_200 as h };
                    let s_100: number;
                    export { s_100 as s };
                    let l_200: number;
                    export { l_200 as l };
                }
                export { hsl_100 as hsl };
                export namespace oklch_100 {
                    let l_201: number;
                    export { l_201 as l };
                    let c_100: number;
                    export { c_100 as c };
                    let h_201: number;
                    export { h_201 as h };
                }
                export { oklch_100 as oklch };
                let accent_68: boolean;
                export { accent_68 as accent };
            }
            export { subtext0_2 as subtext0 };
            export namespace overlay2_2 {
                let name_120: string;
                export { name_120 as name };
                let order_88: number;
                export { order_88 as order };
                let hex_101: string;
                export { hex_101 as hex };
                export namespace rgb_101 {
                    let r_101: number;
                    export { r_101 as r };
                    let g_101: number;
                    export { g_101 as g };
                    let b_101: number;
                    export { b_101 as b };
                }
                export { rgb_101 as rgb };
                export namespace hsl_101 {
                    let h_202: number;
                    export { h_202 as h };
                    let s_101: number;
                    export { s_101 as s };
                    let l_202: number;
                    export { l_202 as l };
                }
                export { hsl_101 as hsl };
                export namespace oklch_101 {
                    let l_203: number;
                    export { l_203 as l };
                    let c_101: number;
                    export { c_101 as c };
                    let h_203: number;
                    export { h_203 as h };
                }
                export { oklch_101 as oklch };
                let accent_69: boolean;
                export { accent_69 as accent };
            }
            export { overlay2_2 as overlay2 };
            export namespace overlay1_2 {
                let name_121: string;
                export { name_121 as name };
                let order_89: number;
                export { order_89 as order };
                let hex_102: string;
                export { hex_102 as hex };
                export namespace rgb_102 {
                    let r_102: number;
                    export { r_102 as r };
                    let g_102: number;
                    export { g_102 as g };
                    let b_102: number;
                    export { b_102 as b };
                }
                export { rgb_102 as rgb };
                export namespace hsl_102 {
                    let h_204: number;
                    export { h_204 as h };
                    let s_102: number;
                    export { s_102 as s };
                    let l_204: number;
                    export { l_204 as l };
                }
                export { hsl_102 as hsl };
                export namespace oklch_102 {
                    let l_205: number;
                    export { l_205 as l };
                    let c_102: number;
                    export { c_102 as c };
                    let h_205: number;
                    export { h_205 as h };
                }
                export { oklch_102 as oklch };
                let accent_70: boolean;
                export { accent_70 as accent };
            }
            export { overlay1_2 as overlay1 };
            export namespace overlay0_2 {
                let name_122: string;
                export { name_122 as name };
                let order_90: number;
                export { order_90 as order };
                let hex_103: string;
                export { hex_103 as hex };
                export namespace rgb_103 {
                    let r_103: number;
                    export { r_103 as r };
                    let g_103: number;
                    export { g_103 as g };
                    let b_103: number;
                    export { b_103 as b };
                }
                export { rgb_103 as rgb };
                export namespace hsl_103 {
                    let h_206: number;
                    export { h_206 as h };
                    let s_103: number;
                    export { s_103 as s };
                    let l_206: number;
                    export { l_206 as l };
                }
                export { hsl_103 as hsl };
                export namespace oklch_103 {
                    let l_207: number;
                    export { l_207 as l };
                    let c_103: number;
                    export { c_103 as c };
                    let h_207: number;
                    export { h_207 as h };
                }
                export { oklch_103 as oklch };
                let accent_71: boolean;
                export { accent_71 as accent };
            }
            export { overlay0_2 as overlay0 };
            export namespace surface2_2 {
                let name_123: string;
                export { name_123 as name };
                let order_91: number;
                export { order_91 as order };
                let hex_104: string;
                export { hex_104 as hex };
                export namespace rgb_104 {
                    let r_104: number;
                    export { r_104 as r };
                    let g_104: number;
                    export { g_104 as g };
                    let b_104: number;
                    export { b_104 as b };
                }
                export { rgb_104 as rgb };
                export namespace hsl_104 {
                    let h_208: number;
                    export { h_208 as h };
                    let s_104: number;
                    export { s_104 as s };
                    let l_208: number;
                    export { l_208 as l };
                }
                export { hsl_104 as hsl };
                export namespace oklch_104 {
                    let l_209: number;
                    export { l_209 as l };
                    let c_104: number;
                    export { c_104 as c };
                    let h_209: number;
                    export { h_209 as h };
                }
                export { oklch_104 as oklch };
                let accent_72: boolean;
                export { accent_72 as accent };
            }
            export { surface2_2 as surface2 };
            export namespace surface1_2 {
                let name_124: string;
                export { name_124 as name };
                let order_92: number;
                export { order_92 as order };
                let hex_105: string;
                export { hex_105 as hex };
                export namespace rgb_105 {
                    let r_105: number;
                    export { r_105 as r };
                    let g_105: number;
                    export { g_105 as g };
                    let b_105: number;
                    export { b_105 as b };
                }
                export { rgb_105 as rgb };
                export namespace hsl_105 {
                    let h_210: number;
                    export { h_210 as h };
                    let s_105: number;
                    export { s_105 as s };
                    let l_210: number;
                    export { l_210 as l };
                }
                export { hsl_105 as hsl };
                export namespace oklch_105 {
                    let l_211: number;
                    export { l_211 as l };
                    let c_105: number;
                    export { c_105 as c };
                    let h_211: number;
                    export { h_211 as h };
                }
                export { oklch_105 as oklch };
                let accent_73: boolean;
                export { accent_73 as accent };
            }
            export { surface1_2 as surface1 };
            export namespace surface0_2 {
                let name_125: string;
                export { name_125 as name };
                let order_93: number;
                export { order_93 as order };
                let hex_106: string;
                export { hex_106 as hex };
                export namespace rgb_106 {
                    let r_106: number;
                    export { r_106 as r };
                    let g_106: number;
                    export { g_106 as g };
                    let b_106: number;
                    export { b_106 as b };
                }
                export { rgb_106 as rgb };
                export namespace hsl_106 {
                    let h_212: number;
                    export { h_212 as h };
                    let s_106: number;
                    export { s_106 as s };
                    let l_212: number;
                    export { l_212 as l };
                }
                export { hsl_106 as hsl };
                export namespace oklch_106 {
                    let l_213: number;
                    export { l_213 as l };
                    let c_106: number;
                    export { c_106 as c };
                    let h_213: number;
                    export { h_213 as h };
                }
                export { oklch_106 as oklch };
                let accent_74: boolean;
                export { accent_74 as accent };
            }
            export { surface0_2 as surface0 };
            export namespace base_2 {
                let name_126: string;
                export { name_126 as name };
                let order_94: number;
                export { order_94 as order };
                let hex_107: string;
                export { hex_107 as hex };
                export namespace rgb_107 {
                    let r_107: number;
                    export { r_107 as r };
                    let g_107: number;
                    export { g_107 as g };
                    let b_107: number;
                    export { b_107 as b };
                }
                export { rgb_107 as rgb };
                export namespace hsl_107 {
                    let h_214: number;
                    export { h_214 as h };
                    let s_107: number;
                    export { s_107 as s };
                    let l_214: number;
                    export { l_214 as l };
                }
                export { hsl_107 as hsl };
                export namespace oklch_107 {
                    let l_215: number;
                    export { l_215 as l };
                    let c_107: number;
                    export { c_107 as c };
                    let h_215: number;
                    export { h_215 as h };
                }
                export { oklch_107 as oklch };
                let accent_75: boolean;
                export { accent_75 as accent };
            }
            export { base_2 as base };
            export namespace mantle_2 {
                let name_127: string;
                export { name_127 as name };
                let order_95: number;
                export { order_95 as order };
                let hex_108: string;
                export { hex_108 as hex };
                export namespace rgb_108 {
                    let r_108: number;
                    export { r_108 as r };
                    let g_108: number;
                    export { g_108 as g };
                    let b_108: number;
                    export { b_108 as b };
                }
                export { rgb_108 as rgb };
                export namespace hsl_108 {
                    let h_216: number;
                    export { h_216 as h };
                    let s_108: number;
                    export { s_108 as s };
                    let l_216: number;
                    export { l_216 as l };
                }
                export { hsl_108 as hsl };
                export namespace oklch_108 {
                    let l_217: number;
                    export { l_217 as l };
                    let c_108: number;
                    export { c_108 as c };
                    let h_217: number;
                    export { h_217 as h };
                }
                export { oklch_108 as oklch };
                let accent_76: boolean;
                export { accent_76 as accent };
            }
            export { mantle_2 as mantle };
            export namespace crust_2 {
                let name_128: string;
                export { name_128 as name };
                let order_96: number;
                export { order_96 as order };
                let hex_109: string;
                export { hex_109 as hex };
                export namespace rgb_109 {
                    let r_109: number;
                    export { r_109 as r };
                    let g_109: number;
                    export { g_109 as g };
                    let b_109: number;
                    export { b_109 as b };
                }
                export { rgb_109 as rgb };
                export namespace hsl_109 {
                    let h_218: number;
                    export { h_218 as h };
                    let s_109: number;
                    export { s_109 as s };
                    let l_218: number;
                    export { l_218 as l };
                }
                export { hsl_109 as hsl };
                export namespace oklch_109 {
                    let l_219: number;
                    export { l_219 as l };
                    let c_109: number;
                    export { c_109 as c };
                    let h_219: number;
                    export { h_219 as h };
                }
                export { oklch_109 as oklch };
                let accent_77: boolean;
                export { accent_77 as accent };
            }
            export { crust_2 as crust };
        }
        export { colors_2 as colors };
        export namespace ansiColors_2 {
            export namespace black_2 {
                let name_129: string;
                export { name_129 as name };
                let order_97: number;
                export { order_97 as order };
                export namespace normal_16 {
                    let name_130: string;
                    export { name_130 as name };
                    let hex_110: string;
                    export { hex_110 as hex };
                    export namespace rgb_110 {
                        let r_110: number;
                        export { r_110 as r };
                        let g_110: number;
                        export { g_110 as g };
                        let b_110: number;
                        export { b_110 as b };
                    }
                    export { rgb_110 as rgb };
                    export namespace hsl_110 {
                        let h_220: number;
                        export { h_220 as h };
                        let s_110: number;
                        export { s_110 as s };
                        let l_220: number;
                        export { l_220 as l };
                    }
                    export { hsl_110 as hsl };
                    export namespace oklch_110 {
                        let l_221: number;
                        export { l_221 as l };
                        let c_110: number;
                        export { c_110 as c };
                        let h_221: number;
                        export { h_221 as h };
                    }
                    export { oklch_110 as oklch };
                    let code_32: number;
                    export { code_32 as code };
                }
                export { normal_16 as normal };
                export namespace bright_16 {
                    let name_131: string;
                    export { name_131 as name };
                    let hex_111: string;
                    export { hex_111 as hex };
                    export namespace rgb_111 {
                        let r_111: number;
                        export { r_111 as r };
                        let g_111: number;
                        export { g_111 as g };
                        let b_111: number;
                        export { b_111 as b };
                    }
                    export { rgb_111 as rgb };
                    export namespace hsl_111 {
                        let h_222: number;
                        export { h_222 as h };
                        let s_111: number;
                        export { s_111 as s };
                        let l_222: number;
                        export { l_222 as l };
                    }
                    export { hsl_111 as hsl };
                    export namespace oklch_111 {
                        let l_223: number;
                        export { l_223 as l };
                        let c_111: number;
                        export { c_111 as c };
                        let h_223: number;
                        export { h_223 as h };
                    }
                    export { oklch_111 as oklch };
                    let code_33: number;
                    export { code_33 as code };
                }
                export { bright_16 as bright };
            }
            export { black_2 as black };
            export namespace red_5 {
                let name_132: string;
                export { name_132 as name };
                let order_98: number;
                export { order_98 as order };
                export namespace normal_17 {
                    let name_133: string;
                    export { name_133 as name };
                    let hex_112: string;
                    export { hex_112 as hex };
                    export namespace rgb_112 {
                        let r_112: number;
                        export { r_112 as r };
                        let g_112: number;
                        export { g_112 as g };
                        let b_112: number;
                        export { b_112 as b };
                    }
                    export { rgb_112 as rgb };
                    export namespace hsl_112 {
                        let h_224: number;
                        export { h_224 as h };
                        let s_112: number;
                        export { s_112 as s };
                        let l_224: number;
                        export { l_224 as l };
                    }
                    export { hsl_112 as hsl };
                    export namespace oklch_112 {
                        let l_225: number;
                        export { l_225 as l };
                        let c_112: number;
                        export { c_112 as c };
                        let h_225: number;
                        export { h_225 as h };
                    }
                    export { oklch_112 as oklch };
                    let code_34: number;
                    export { code_34 as code };
                }
                export { normal_17 as normal };
                export namespace bright_17 {
                    let name_134: string;
                    export { name_134 as name };
                    let hex_113: string;
                    export { hex_113 as hex };
                    export namespace rgb_113 {
                        let r_113: number;
                        export { r_113 as r };
                        let g_113: number;
                        export { g_113 as g };
                        let b_113: number;
                        export { b_113 as b };
                    }
                    export { rgb_113 as rgb };
                    export namespace hsl_113 {
                        let h_226: number;
                        export { h_226 as h };
                        let s_113: number;
                        export { s_113 as s };
                        let l_226: number;
                        export { l_226 as l };
                    }
                    export { hsl_113 as hsl };
                    export namespace oklch_113 {
                        let l_227: number;
                        export { l_227 as l };
                        let c_113: number;
                        export { c_113 as c };
                        let h_227: number;
                        export { h_227 as h };
                    }
                    export { oklch_113 as oklch };
                    let code_35: number;
                    export { code_35 as code };
                }
                export { bright_17 as bright };
            }
            export { red_5 as red };
            export namespace green_5 {
                let name_135: string;
                export { name_135 as name };
                let order_99: number;
                export { order_99 as order };
                export namespace normal_18 {
                    let name_136: string;
                    export { name_136 as name };
                    let hex_114: string;
                    export { hex_114 as hex };
                    export namespace rgb_114 {
                        let r_114: number;
                        export { r_114 as r };
                        let g_114: number;
                        export { g_114 as g };
                        let b_114: number;
                        export { b_114 as b };
                    }
                    export { rgb_114 as rgb };
                    export namespace hsl_114 {
                        let h_228: number;
                        export { h_228 as h };
                        let s_114: number;
                        export { s_114 as s };
                        let l_228: number;
                        export { l_228 as l };
                    }
                    export { hsl_114 as hsl };
                    export namespace oklch_114 {
                        let l_229: number;
                        export { l_229 as l };
                        let c_114: number;
                        export { c_114 as c };
                        let h_229: number;
                        export { h_229 as h };
                    }
                    export { oklch_114 as oklch };
                    let code_36: number;
                    export { code_36 as code };
                }
                export { normal_18 as normal };
                export namespace bright_18 {
                    let name_137: string;
                    export { name_137 as name };
                    let hex_115: string;
                    export { hex_115 as hex };
                    export namespace rgb_115 {
                        let r_115: number;
                        export { r_115 as r };
                        let g_115: number;
                        export { g_115 as g };
                        let b_115: number;
                        export { b_115 as b };
                    }
                    export { rgb_115 as rgb };
                    export namespace hsl_115 {
                        let h_230: number;
                        export { h_230 as h };
                        let s_115: number;
                        export { s_115 as s };
                        let l_230: number;
                        export { l_230 as l };
                    }
                    export { hsl_115 as hsl };
                    export namespace oklch_115 {
                        let l_231: number;
                        export { l_231 as l };
                        let c_115: number;
                        export { c_115 as c };
                        let h_231: number;
                        export { h_231 as h };
                    }
                    export { oklch_115 as oklch };
                    let code_37: number;
                    export { code_37 as code };
                }
                export { bright_18 as bright };
            }
            export { green_5 as green };
            export namespace yellow_5 {
                let name_138: string;
                export { name_138 as name };
                let order_100: number;
                export { order_100 as order };
                export namespace normal_19 {
                    let name_139: string;
                    export { name_139 as name };
                    let hex_116: string;
                    export { hex_116 as hex };
                    export namespace rgb_116 {
                        let r_116: number;
                        export { r_116 as r };
                        let g_116: number;
                        export { g_116 as g };
                        let b_116: number;
                        export { b_116 as b };
                    }
                    export { rgb_116 as rgb };
                    export namespace hsl_116 {
                        let h_232: number;
                        export { h_232 as h };
                        let s_116: number;
                        export { s_116 as s };
                        let l_232: number;
                        export { l_232 as l };
                    }
                    export { hsl_116 as hsl };
                    export namespace oklch_116 {
                        let l_233: number;
                        export { l_233 as l };
                        let c_116: number;
                        export { c_116 as c };
                        let h_233: number;
                        export { h_233 as h };
                    }
                    export { oklch_116 as oklch };
                    let code_38: number;
                    export { code_38 as code };
                }
                export { normal_19 as normal };
                export namespace bright_19 {
                    let name_140: string;
                    export { name_140 as name };
                    let hex_117: string;
                    export { hex_117 as hex };
                    export namespace rgb_117 {
                        let r_117: number;
                        export { r_117 as r };
                        let g_117: number;
                        export { g_117 as g };
                        let b_117: number;
                        export { b_117 as b };
                    }
                    export { rgb_117 as rgb };
                    export namespace hsl_117 {
                        let h_234: number;
                        export { h_234 as h };
                        let s_117: number;
                        export { s_117 as s };
                        let l_234: number;
                        export { l_234 as l };
                    }
                    export { hsl_117 as hsl };
                    export namespace oklch_117 {
                        let l_235: number;
                        export { l_235 as l };
                        let c_117: number;
                        export { c_117 as c };
                        let h_235: number;
                        export { h_235 as h };
                    }
                    export { oklch_117 as oklch };
                    let code_39: number;
                    export { code_39 as code };
                }
                export { bright_19 as bright };
            }
            export { yellow_5 as yellow };
            export namespace blue_5 {
                let name_141: string;
                export { name_141 as name };
                let order_101: number;
                export { order_101 as order };
                export namespace normal_20 {
                    let name_142: string;
                    export { name_142 as name };
                    let hex_118: string;
                    export { hex_118 as hex };
                    export namespace rgb_118 {
                        let r_118: number;
                        export { r_118 as r };
                        let g_118: number;
                        export { g_118 as g };
                        let b_118: number;
                        export { b_118 as b };
                    }
                    export { rgb_118 as rgb };
                    export namespace hsl_118 {
                        let h_236: number;
                        export { h_236 as h };
                        let s_118: number;
                        export { s_118 as s };
                        let l_236: number;
                        export { l_236 as l };
                    }
                    export { hsl_118 as hsl };
                    export namespace oklch_118 {
                        let l_237: number;
                        export { l_237 as l };
                        let c_118: number;
                        export { c_118 as c };
                        let h_237: number;
                        export { h_237 as h };
                    }
                    export { oklch_118 as oklch };
                    let code_40: number;
                    export { code_40 as code };
                }
                export { normal_20 as normal };
                export namespace bright_20 {
                    let name_143: string;
                    export { name_143 as name };
                    let hex_119: string;
                    export { hex_119 as hex };
                    export namespace rgb_119 {
                        let r_119: number;
                        export { r_119 as r };
                        let g_119: number;
                        export { g_119 as g };
                        let b_119: number;
                        export { b_119 as b };
                    }
                    export { rgb_119 as rgb };
                    export namespace hsl_119 {
                        let h_238: number;
                        export { h_238 as h };
                        let s_119: number;
                        export { s_119 as s };
                        let l_238: number;
                        export { l_238 as l };
                    }
                    export { hsl_119 as hsl };
                    export namespace oklch_119 {
                        let l_239: number;
                        export { l_239 as l };
                        let c_119: number;
                        export { c_119 as c };
                        let h_239: number;
                        export { h_239 as h };
                    }
                    export { oklch_119 as oklch };
                    let code_41: number;
                    export { code_41 as code };
                }
                export { bright_20 as bright };
            }
            export { blue_5 as blue };
            export namespace magenta_2 {
                let name_144: string;
                export { name_144 as name };
                let order_102: number;
                export { order_102 as order };
                export namespace normal_21 {
                    let name_145: string;
                    export { name_145 as name };
                    let hex_120: string;
                    export { hex_120 as hex };
                    export namespace rgb_120 {
                        let r_120: number;
                        export { r_120 as r };
                        let g_120: number;
                        export { g_120 as g };
                        let b_120: number;
                        export { b_120 as b };
                    }
                    export { rgb_120 as rgb };
                    export namespace hsl_120 {
                        let h_240: number;
                        export { h_240 as h };
                        let s_120: number;
                        export { s_120 as s };
                        let l_240: number;
                        export { l_240 as l };
                    }
                    export { hsl_120 as hsl };
                    export namespace oklch_120 {
                        let l_241: number;
                        export { l_241 as l };
                        let c_120: number;
                        export { c_120 as c };
                        let h_241: number;
                        export { h_241 as h };
                    }
                    export { oklch_120 as oklch };
                    let code_42: number;
                    export { code_42 as code };
                }
                export { normal_21 as normal };
                export namespace bright_21 {
                    let name_146: string;
                    export { name_146 as name };
                    let hex_121: string;
                    export { hex_121 as hex };
                    export namespace rgb_121 {
                        let r_121: number;
                        export { r_121 as r };
                        let g_121: number;
                        export { g_121 as g };
                        let b_121: number;
                        export { b_121 as b };
                    }
                    export { rgb_121 as rgb };
                    export namespace hsl_121 {
                        let h_242: number;
                        export { h_242 as h };
                        let s_121: number;
                        export { s_121 as s };
                        let l_242: number;
                        export { l_242 as l };
                    }
                    export { hsl_121 as hsl };
                    export namespace oklch_121 {
                        let l_243: number;
                        export { l_243 as l };
                        let c_121: number;
                        export { c_121 as c };
                        let h_243: number;
                        export { h_243 as h };
                    }
                    export { oklch_121 as oklch };
                    let code_43: number;
                    export { code_43 as code };
                }
                export { bright_21 as bright };
            }
            export { magenta_2 as magenta };
            export namespace cyan_2 {
                let name_147: string;
                export { name_147 as name };
                let order_103: number;
                export { order_103 as order };
                export namespace normal_22 {
                    let name_148: string;
                    export { name_148 as name };
                    let hex_122: string;
                    export { hex_122 as hex };
                    export namespace rgb_122 {
                        let r_122: number;
                        export { r_122 as r };
                        let g_122: number;
                        export { g_122 as g };
                        let b_122: number;
                        export { b_122 as b };
                    }
                    export { rgb_122 as rgb };
                    export namespace hsl_122 {
                        let h_244: number;
                        export { h_244 as h };
                        let s_122: number;
                        export { s_122 as s };
                        let l_244: number;
                        export { l_244 as l };
                    }
                    export { hsl_122 as hsl };
                    export namespace oklch_122 {
                        let l_245: number;
                        export { l_245 as l };
                        let c_122: number;
                        export { c_122 as c };
                        let h_245: number;
                        export { h_245 as h };
                    }
                    export { oklch_122 as oklch };
                    let code_44: number;
                    export { code_44 as code };
                }
                export { normal_22 as normal };
                export namespace bright_22 {
                    let name_149: string;
                    export { name_149 as name };
                    let hex_123: string;
                    export { hex_123 as hex };
                    export namespace rgb_123 {
                        let r_123: number;
                        export { r_123 as r };
                        let g_123: number;
                        export { g_123 as g };
                        let b_123: number;
                        export { b_123 as b };
                    }
                    export { rgb_123 as rgb };
                    export namespace hsl_123 {
                        let h_246: number;
                        export { h_246 as h };
                        let s_123: number;
                        export { s_123 as s };
                        let l_246: number;
                        export { l_246 as l };
                    }
                    export { hsl_123 as hsl };
                    export namespace oklch_123 {
                        let l_247: number;
                        export { l_247 as l };
                        let c_123: number;
                        export { c_123 as c };
                        let h_247: number;
                        export { h_247 as h };
                    }
                    export { oklch_123 as oklch };
                    let code_45: number;
                    export { code_45 as code };
                }
                export { bright_22 as bright };
            }
            export { cyan_2 as cyan };
            export namespace white_2 {
                let name_150: string;
                export { name_150 as name };
                let order_104: number;
                export { order_104 as order };
                export namespace normal_23 {
                    let name_151: string;
                    export { name_151 as name };
                    let hex_124: string;
                    export { hex_124 as hex };
                    export namespace rgb_124 {
                        let r_124: number;
                        export { r_124 as r };
                        let g_124: number;
                        export { g_124 as g };
                        let b_124: number;
                        export { b_124 as b };
                    }
                    export { rgb_124 as rgb };
                    export namespace hsl_124 {
                        let h_248: number;
                        export { h_248 as h };
                        let s_124: number;
                        export { s_124 as s };
                        let l_248: number;
                        export { l_248 as l };
                    }
                    export { hsl_124 as hsl };
                    export namespace oklch_124 {
                        let l_249: number;
                        export { l_249 as l };
                        let c_124: number;
                        export { c_124 as c };
                        let h_249: number;
                        export { h_249 as h };
                    }
                    export { oklch_124 as oklch };
                    let code_46: number;
                    export { code_46 as code };
                }
                export { normal_23 as normal };
                export namespace bright_23 {
                    let name_152: string;
                    export { name_152 as name };
                    let hex_125: string;
                    export { hex_125 as hex };
                    export namespace rgb_125 {
                        let r_125: number;
                        export { r_125 as r };
                        let g_125: number;
                        export { g_125 as g };
                        let b_125: number;
                        export { b_125 as b };
                    }
                    export { rgb_125 as rgb };
                    export namespace hsl_125 {
                        let h_250: number;
                        export { h_250 as h };
                        let s_125: number;
                        export { s_125 as s };
                        let l_250: number;
                        export { l_250 as l };
                    }
                    export { hsl_125 as hsl };
                    export namespace oklch_125 {
                        let l_251: number;
                        export { l_251 as l };
                        let c_125: number;
                        export { c_125 as c };
                        let h_251: number;
                        export { h_251 as h };
                    }
                    export { oklch_125 as oklch };
                    let code_47: number;
                    export { code_47 as code };
                }
                export { bright_23 as bright };
            }
            export { white_2 as white };
        }
        export { ansiColors_2 as ansiColors };
    }
    namespace mocha {
        let name_153: string;
        export { name_153 as name };
        let emoji_3: string;
        export { emoji_3 as emoji };
        let order_105: number;
        export { order_105 as order };
        let dark_3: boolean;
        export { dark_3 as dark };
        export namespace colors_3 {
            export namespace rosewater_3 {
                let name_154: string;
                export { name_154 as name };
                let order_106: number;
                export { order_106 as order };
                let hex_126: string;
                export { hex_126 as hex };
                export namespace rgb_126 {
                    let r_126: number;
                    export { r_126 as r };
                    let g_126: number;
                    export { g_126 as g };
                    let b_126: number;
                    export { b_126 as b };
                }
                export { rgb_126 as rgb };
                export namespace hsl_126 {
                    let h_252: number;
                    export { h_252 as h };
                    let s_126: number;
                    export { s_126 as s };
                    let l_252: number;
                    export { l_252 as l };
                }
                export { hsl_126 as hsl };
                export namespace oklch_126 {
                    let l_253: number;
                    export { l_253 as l };
                    let c_126: number;
                    export { c_126 as c };
                    let h_253: number;
                    export { h_253 as h };
                }
                export { oklch_126 as oklch };
                let accent_78: boolean;
                export { accent_78 as accent };
            }
            export { rosewater_3 as rosewater };
            export namespace flamingo_3 {
                let name_155: string;
                export { name_155 as name };
                let order_107: number;
                export { order_107 as order };
                let hex_127: string;
                export { hex_127 as hex };
                export namespace rgb_127 {
                    let r_127: number;
                    export { r_127 as r };
                    let g_127: number;
                    export { g_127 as g };
                    let b_127: number;
                    export { b_127 as b };
                }
                export { rgb_127 as rgb };
                export namespace hsl_127 {
                    let h_254: number;
                    export { h_254 as h };
                    let s_127: number;
                    export { s_127 as s };
                    let l_254: number;
                    export { l_254 as l };
                }
                export { hsl_127 as hsl };
                export namespace oklch_127 {
                    let l_255: number;
                    export { l_255 as l };
                    let c_127: number;
                    export { c_127 as c };
                    let h_255: number;
                    export { h_255 as h };
                }
                export { oklch_127 as oklch };
                let accent_79: boolean;
                export { accent_79 as accent };
            }
            export { flamingo_3 as flamingo };
            export namespace pink_3 {
                let name_156: string;
                export { name_156 as name };
                let order_108: number;
                export { order_108 as order };
                let hex_128: string;
                export { hex_128 as hex };
                export namespace rgb_128 {
                    let r_128: number;
                    export { r_128 as r };
                    let g_128: number;
                    export { g_128 as g };
                    let b_128: number;
                    export { b_128 as b };
                }
                export { rgb_128 as rgb };
                export namespace hsl_128 {
                    let h_256: number;
                    export { h_256 as h };
                    let s_128: number;
                    export { s_128 as s };
                    let l_256: number;
                    export { l_256 as l };
                }
                export { hsl_128 as hsl };
                export namespace oklch_128 {
                    let l_257: number;
                    export { l_257 as l };
                    let c_128: number;
                    export { c_128 as c };
                    let h_257: number;
                    export { h_257 as h };
                }
                export { oklch_128 as oklch };
                let accent_80: boolean;
                export { accent_80 as accent };
            }
            export { pink_3 as pink };
            export namespace mauve_3 {
                let name_157: string;
                export { name_157 as name };
                let order_109: number;
                export { order_109 as order };
                let hex_129: string;
                export { hex_129 as hex };
                export namespace rgb_129 {
                    let r_129: number;
                    export { r_129 as r };
                    let g_129: number;
                    export { g_129 as g };
                    let b_129: number;
                    export { b_129 as b };
                }
                export { rgb_129 as rgb };
                export namespace hsl_129 {
                    let h_258: number;
                    export { h_258 as h };
                    let s_129: number;
                    export { s_129 as s };
                    let l_258: number;
                    export { l_258 as l };
                }
                export { hsl_129 as hsl };
                export namespace oklch_129 {
                    let l_259: number;
                    export { l_259 as l };
                    let c_129: number;
                    export { c_129 as c };
                    let h_259: number;
                    export { h_259 as h };
                }
                export { oklch_129 as oklch };
                let accent_81: boolean;
                export { accent_81 as accent };
            }
            export { mauve_3 as mauve };
            export namespace red_6 {
                let name_158: string;
                export { name_158 as name };
                let order_110: number;
                export { order_110 as order };
                let hex_130: string;
                export { hex_130 as hex };
                export namespace rgb_130 {
                    let r_130: number;
                    export { r_130 as r };
                    let g_130: number;
                    export { g_130 as g };
                    let b_130: number;
                    export { b_130 as b };
                }
                export { rgb_130 as rgb };
                export namespace hsl_130 {
                    let h_260: number;
                    export { h_260 as h };
                    let s_130: number;
                    export { s_130 as s };
                    let l_260: number;
                    export { l_260 as l };
                }
                export { hsl_130 as hsl };
                export namespace oklch_130 {
                    let l_261: number;
                    export { l_261 as l };
                    let c_130: number;
                    export { c_130 as c };
                    let h_261: number;
                    export { h_261 as h };
                }
                export { oklch_130 as oklch };
                let accent_82: boolean;
                export { accent_82 as accent };
            }
            export { red_6 as red };
            export namespace maroon_3 {
                let name_159: string;
                export { name_159 as name };
                let order_111: number;
                export { order_111 as order };
                let hex_131: string;
                export { hex_131 as hex };
                export namespace rgb_131 {
                    let r_131: number;
                    export { r_131 as r };
                    let g_131: number;
                    export { g_131 as g };
                    let b_131: number;
                    export { b_131 as b };
                }
                export { rgb_131 as rgb };
                export namespace hsl_131 {
                    let h_262: number;
                    export { h_262 as h };
                    let s_131: number;
                    export { s_131 as s };
                    let l_262: number;
                    export { l_262 as l };
                }
                export { hsl_131 as hsl };
                export namespace oklch_131 {
                    let l_263: number;
                    export { l_263 as l };
                    let c_131: number;
                    export { c_131 as c };
                    let h_263: number;
                    export { h_263 as h };
                }
                export { oklch_131 as oklch };
                let accent_83: boolean;
                export { accent_83 as accent };
            }
            export { maroon_3 as maroon };
            export namespace peach_3 {
                let name_160: string;
                export { name_160 as name };
                let order_112: number;
                export { order_112 as order };
                let hex_132: string;
                export { hex_132 as hex };
                export namespace rgb_132 {
                    let r_132: number;
                    export { r_132 as r };
                    let g_132: number;
                    export { g_132 as g };
                    let b_132: number;
                    export { b_132 as b };
                }
                export { rgb_132 as rgb };
                export namespace hsl_132 {
                    let h_264: number;
                    export { h_264 as h };
                    let s_132: number;
                    export { s_132 as s };
                    let l_264: number;
                    export { l_264 as l };
                }
                export { hsl_132 as hsl };
                export namespace oklch_132 {
                    let l_265: number;
                    export { l_265 as l };
                    let c_132: number;
                    export { c_132 as c };
                    let h_265: number;
                    export { h_265 as h };
                }
                export { oklch_132 as oklch };
                let accent_84: boolean;
                export { accent_84 as accent };
            }
            export { peach_3 as peach };
            export namespace yellow_6 {
                let name_161: string;
                export { name_161 as name };
                let order_113: number;
                export { order_113 as order };
                let hex_133: string;
                export { hex_133 as hex };
                export namespace rgb_133 {
                    let r_133: number;
                    export { r_133 as r };
                    let g_133: number;
                    export { g_133 as g };
                    let b_133: number;
                    export { b_133 as b };
                }
                export { rgb_133 as rgb };
                export namespace hsl_133 {
                    let h_266: number;
                    export { h_266 as h };
                    let s_133: number;
                    export { s_133 as s };
                    let l_266: number;
                    export { l_266 as l };
                }
                export { hsl_133 as hsl };
                export namespace oklch_133 {
                    let l_267: number;
                    export { l_267 as l };
                    let c_133: number;
                    export { c_133 as c };
                    let h_267: number;
                    export { h_267 as h };
                }
                export { oklch_133 as oklch };
                let accent_85: boolean;
                export { accent_85 as accent };
            }
            export { yellow_6 as yellow };
            export namespace green_6 {
                let name_162: string;
                export { name_162 as name };
                let order_114: number;
                export { order_114 as order };
                let hex_134: string;
                export { hex_134 as hex };
                export namespace rgb_134 {
                    let r_134: number;
                    export { r_134 as r };
                    let g_134: number;
                    export { g_134 as g };
                    let b_134: number;
                    export { b_134 as b };
                }
                export { rgb_134 as rgb };
                export namespace hsl_134 {
                    let h_268: number;
                    export { h_268 as h };
                    let s_134: number;
                    export { s_134 as s };
                    let l_268: number;
                    export { l_268 as l };
                }
                export { hsl_134 as hsl };
                export namespace oklch_134 {
                    let l_269: number;
                    export { l_269 as l };
                    let c_134: number;
                    export { c_134 as c };
                    let h_269: number;
                    export { h_269 as h };
                }
                export { oklch_134 as oklch };
                let accent_86: boolean;
                export { accent_86 as accent };
            }
            export { green_6 as green };
            export namespace teal_3 {
                let name_163: string;
                export { name_163 as name };
                let order_115: number;
                export { order_115 as order };
                let hex_135: string;
                export { hex_135 as hex };
                export namespace rgb_135 {
                    let r_135: number;
                    export { r_135 as r };
                    let g_135: number;
                    export { g_135 as g };
                    let b_135: number;
                    export { b_135 as b };
                }
                export { rgb_135 as rgb };
                export namespace hsl_135 {
                    let h_270: number;
                    export { h_270 as h };
                    let s_135: number;
                    export { s_135 as s };
                    let l_270: number;
                    export { l_270 as l };
                }
                export { hsl_135 as hsl };
                export namespace oklch_135 {
                    let l_271: number;
                    export { l_271 as l };
                    let c_135: number;
                    export { c_135 as c };
                    let h_271: number;
                    export { h_271 as h };
                }
                export { oklch_135 as oklch };
                let accent_87: boolean;
                export { accent_87 as accent };
            }
            export { teal_3 as teal };
            export namespace sky_3 {
                let name_164: string;
                export { name_164 as name };
                let order_116: number;
                export { order_116 as order };
                let hex_136: string;
                export { hex_136 as hex };
                export namespace rgb_136 {
                    let r_136: number;
                    export { r_136 as r };
                    let g_136: number;
                    export { g_136 as g };
                    let b_136: number;
                    export { b_136 as b };
                }
                export { rgb_136 as rgb };
                export namespace hsl_136 {
                    let h_272: number;
                    export { h_272 as h };
                    let s_136: number;
                    export { s_136 as s };
                    let l_272: number;
                    export { l_272 as l };
                }
                export { hsl_136 as hsl };
                export namespace oklch_136 {
                    let l_273: number;
                    export { l_273 as l };
                    let c_136: number;
                    export { c_136 as c };
                    let h_273: number;
                    export { h_273 as h };
                }
                export { oklch_136 as oklch };
                let accent_88: boolean;
                export { accent_88 as accent };
            }
            export { sky_3 as sky };
            export namespace sapphire_3 {
                let name_165: string;
                export { name_165 as name };
                let order_117: number;
                export { order_117 as order };
                let hex_137: string;
                export { hex_137 as hex };
                export namespace rgb_137 {
                    let r_137: number;
                    export { r_137 as r };
                    let g_137: number;
                    export { g_137 as g };
                    let b_137: number;
                    export { b_137 as b };
                }
                export { rgb_137 as rgb };
                export namespace hsl_137 {
                    let h_274: number;
                    export { h_274 as h };
                    let s_137: number;
                    export { s_137 as s };
                    let l_274: number;
                    export { l_274 as l };
                }
                export { hsl_137 as hsl };
                export namespace oklch_137 {
                    let l_275: number;
                    export { l_275 as l };
                    let c_137: number;
                    export { c_137 as c };
                    let h_275: number;
                    export { h_275 as h };
                }
                export { oklch_137 as oklch };
                let accent_89: boolean;
                export { accent_89 as accent };
            }
            export { sapphire_3 as sapphire };
            export namespace blue_6 {
                let name_166: string;
                export { name_166 as name };
                let order_118: number;
                export { order_118 as order };
                let hex_138: string;
                export { hex_138 as hex };
                export namespace rgb_138 {
                    let r_138: number;
                    export { r_138 as r };
                    let g_138: number;
                    export { g_138 as g };
                    let b_138: number;
                    export { b_138 as b };
                }
                export { rgb_138 as rgb };
                export namespace hsl_138 {
                    let h_276: number;
                    export { h_276 as h };
                    let s_138: number;
                    export { s_138 as s };
                    let l_276: number;
                    export { l_276 as l };
                }
                export { hsl_138 as hsl };
                export namespace oklch_138 {
                    let l_277: number;
                    export { l_277 as l };
                    let c_138: number;
                    export { c_138 as c };
                    let h_277: number;
                    export { h_277 as h };
                }
                export { oklch_138 as oklch };
                let accent_90: boolean;
                export { accent_90 as accent };
            }
            export { blue_6 as blue };
            export namespace lavender_3 {
                let name_167: string;
                export { name_167 as name };
                let order_119: number;
                export { order_119 as order };
                let hex_139: string;
                export { hex_139 as hex };
                export namespace rgb_139 {
                    let r_139: number;
                    export { r_139 as r };
                    let g_139: number;
                    export { g_139 as g };
                    let b_139: number;
                    export { b_139 as b };
                }
                export { rgb_139 as rgb };
                export namespace hsl_139 {
                    let h_278: number;
                    export { h_278 as h };
                    let s_139: number;
                    export { s_139 as s };
                    let l_278: number;
                    export { l_278 as l };
                }
                export { hsl_139 as hsl };
                export namespace oklch_139 {
                    let l_279: number;
                    export { l_279 as l };
                    let c_139: number;
                    export { c_139 as c };
                    let h_279: number;
                    export { h_279 as h };
                }
                export { oklch_139 as oklch };
                let accent_91: boolean;
                export { accent_91 as accent };
            }
            export { lavender_3 as lavender };
            export namespace text_3 {
                let name_168: string;
                export { name_168 as name };
                let order_120: number;
                export { order_120 as order };
                let hex_140: string;
                export { hex_140 as hex };
                export namespace rgb_140 {
                    let r_140: number;
                    export { r_140 as r };
                    let g_140: number;
                    export { g_140 as g };
                    let b_140: number;
                    export { b_140 as b };
                }
                export { rgb_140 as rgb };
                export namespace hsl_140 {
                    let h_280: number;
                    export { h_280 as h };
                    let s_140: number;
                    export { s_140 as s };
                    let l_280: number;
                    export { l_280 as l };
                }
                export { hsl_140 as hsl };
                export namespace oklch_140 {
                    let l_281: number;
                    export { l_281 as l };
                    let c_140: number;
                    export { c_140 as c };
                    let h_281: number;
                    export { h_281 as h };
                }
                export { oklch_140 as oklch };
                let accent_92: boolean;
                export { accent_92 as accent };
            }
            export { text_3 as text };
            export namespace subtext1_3 {
                let name_169: string;
                export { name_169 as name };
                let order_121: number;
                export { order_121 as order };
                let hex_141: string;
                export { hex_141 as hex };
                export namespace rgb_141 {
                    let r_141: number;
                    export { r_141 as r };
                    let g_141: number;
                    export { g_141 as g };
                    let b_141: number;
                    export { b_141 as b };
                }
                export { rgb_141 as rgb };
                export namespace hsl_141 {
                    let h_282: number;
                    export { h_282 as h };
                    let s_141: number;
                    export { s_141 as s };
                    let l_282: number;
                    export { l_282 as l };
                }
                export { hsl_141 as hsl };
                export namespace oklch_141 {
                    let l_283: number;
                    export { l_283 as l };
                    let c_141: number;
                    export { c_141 as c };
                    let h_283: number;
                    export { h_283 as h };
                }
                export { oklch_141 as oklch };
                let accent_93: boolean;
                export { accent_93 as accent };
            }
            export { subtext1_3 as subtext1 };
            export namespace subtext0_3 {
                let name_170: string;
                export { name_170 as name };
                let order_122: number;
                export { order_122 as order };
                let hex_142: string;
                export { hex_142 as hex };
                export namespace rgb_142 {
                    let r_142: number;
                    export { r_142 as r };
                    let g_142: number;
                    export { g_142 as g };
                    let b_142: number;
                    export { b_142 as b };
                }
                export { rgb_142 as rgb };
                export namespace hsl_142 {
                    let h_284: number;
                    export { h_284 as h };
                    let s_142: number;
                    export { s_142 as s };
                    let l_284: number;
                    export { l_284 as l };
                }
                export { hsl_142 as hsl };
                export namespace oklch_142 {
                    let l_285: number;
                    export { l_285 as l };
                    let c_142: number;
                    export { c_142 as c };
                    let h_285: number;
                    export { h_285 as h };
                }
                export { oklch_142 as oklch };
                let accent_94: boolean;
                export { accent_94 as accent };
            }
            export { subtext0_3 as subtext0 };
            export namespace overlay2_3 {
                let name_171: string;
                export { name_171 as name };
                let order_123: number;
                export { order_123 as order };
                let hex_143: string;
                export { hex_143 as hex };
                export namespace rgb_143 {
                    let r_143: number;
                    export { r_143 as r };
                    let g_143: number;
                    export { g_143 as g };
                    let b_143: number;
                    export { b_143 as b };
                }
                export { rgb_143 as rgb };
                export namespace hsl_143 {
                    let h_286: number;
                    export { h_286 as h };
                    let s_143: number;
                    export { s_143 as s };
                    let l_286: number;
                    export { l_286 as l };
                }
                export { hsl_143 as hsl };
                export namespace oklch_143 {
                    let l_287: number;
                    export { l_287 as l };
                    let c_143: number;
                    export { c_143 as c };
                    let h_287: number;
                    export { h_287 as h };
                }
                export { oklch_143 as oklch };
                let accent_95: boolean;
                export { accent_95 as accent };
            }
            export { overlay2_3 as overlay2 };
            export namespace overlay1_3 {
                let name_172: string;
                export { name_172 as name };
                let order_124: number;
                export { order_124 as order };
                let hex_144: string;
                export { hex_144 as hex };
                export namespace rgb_144 {
                    let r_144: number;
                    export { r_144 as r };
                    let g_144: number;
                    export { g_144 as g };
                    let b_144: number;
                    export { b_144 as b };
                }
                export { rgb_144 as rgb };
                export namespace hsl_144 {
                    let h_288: number;
                    export { h_288 as h };
                    let s_144: number;
                    export { s_144 as s };
                    let l_288: number;
                    export { l_288 as l };
                }
                export { hsl_144 as hsl };
                export namespace oklch_144 {
                    let l_289: number;
                    export { l_289 as l };
                    let c_144: number;
                    export { c_144 as c };
                    let h_289: number;
                    export { h_289 as h };
                }
                export { oklch_144 as oklch };
                let accent_96: boolean;
                export { accent_96 as accent };
            }
            export { overlay1_3 as overlay1 };
            export namespace overlay0_3 {
                let name_173: string;
                export { name_173 as name };
                let order_125: number;
                export { order_125 as order };
                let hex_145: string;
                export { hex_145 as hex };
                export namespace rgb_145 {
                    let r_145: number;
                    export { r_145 as r };
                    let g_145: number;
                    export { g_145 as g };
                    let b_145: number;
                    export { b_145 as b };
                }
                export { rgb_145 as rgb };
                export namespace hsl_145 {
                    let h_290: number;
                    export { h_290 as h };
                    let s_145: number;
                    export { s_145 as s };
                    let l_290: number;
                    export { l_290 as l };
                }
                export { hsl_145 as hsl };
                export namespace oklch_145 {
                    let l_291: number;
                    export { l_291 as l };
                    let c_145: number;
                    export { c_145 as c };
                    let h_291: number;
                    export { h_291 as h };
                }
                export { oklch_145 as oklch };
                let accent_97: boolean;
                export { accent_97 as accent };
            }
            export { overlay0_3 as overlay0 };
            export namespace surface2_3 {
                let name_174: string;
                export { name_174 as name };
                let order_126: number;
                export { order_126 as order };
                let hex_146: string;
                export { hex_146 as hex };
                export namespace rgb_146 {
                    let r_146: number;
                    export { r_146 as r };
                    let g_146: number;
                    export { g_146 as g };
                    let b_146: number;
                    export { b_146 as b };
                }
                export { rgb_146 as rgb };
                export namespace hsl_146 {
                    let h_292: number;
                    export { h_292 as h };
                    let s_146: number;
                    export { s_146 as s };
                    let l_292: number;
                    export { l_292 as l };
                }
                export { hsl_146 as hsl };
                export namespace oklch_146 {
                    let l_293: number;
                    export { l_293 as l };
                    let c_146: number;
                    export { c_146 as c };
                    let h_293: number;
                    export { h_293 as h };
                }
                export { oklch_146 as oklch };
                let accent_98: boolean;
                export { accent_98 as accent };
            }
            export { surface2_3 as surface2 };
            export namespace surface1_3 {
                let name_175: string;
                export { name_175 as name };
                let order_127: number;
                export { order_127 as order };
                let hex_147: string;
                export { hex_147 as hex };
                export namespace rgb_147 {
                    let r_147: number;
                    export { r_147 as r };
                    let g_147: number;
                    export { g_147 as g };
                    let b_147: number;
                    export { b_147 as b };
                }
                export { rgb_147 as rgb };
                export namespace hsl_147 {
                    let h_294: number;
                    export { h_294 as h };
                    let s_147: number;
                    export { s_147 as s };
                    let l_294: number;
                    export { l_294 as l };
                }
                export { hsl_147 as hsl };
                export namespace oklch_147 {
                    let l_295: number;
                    export { l_295 as l };
                    let c_147: number;
                    export { c_147 as c };
                    let h_295: number;
                    export { h_295 as h };
                }
                export { oklch_147 as oklch };
                let accent_99: boolean;
                export { accent_99 as accent };
            }
            export { surface1_3 as surface1 };
            export namespace surface0_3 {
                let name_176: string;
                export { name_176 as name };
                let order_128: number;
                export { order_128 as order };
                let hex_148: string;
                export { hex_148 as hex };
                export namespace rgb_148 {
                    let r_148: number;
                    export { r_148 as r };
                    let g_148: number;
                    export { g_148 as g };
                    let b_148: number;
                    export { b_148 as b };
                }
                export { rgb_148 as rgb };
                export namespace hsl_148 {
                    let h_296: number;
                    export { h_296 as h };
                    let s_148: number;
                    export { s_148 as s };
                    let l_296: number;
                    export { l_296 as l };
                }
                export { hsl_148 as hsl };
                export namespace oklch_148 {
                    let l_297: number;
                    export { l_297 as l };
                    let c_148: number;
                    export { c_148 as c };
                    let h_297: number;
                    export { h_297 as h };
                }
                export { oklch_148 as oklch };
                let accent_100: boolean;
                export { accent_100 as accent };
            }
            export { surface0_3 as surface0 };
            export namespace base_3 {
                let name_177: string;
                export { name_177 as name };
                let order_129: number;
                export { order_129 as order };
                let hex_149: string;
                export { hex_149 as hex };
                export namespace rgb_149 {
                    let r_149: number;
                    export { r_149 as r };
                    let g_149: number;
                    export { g_149 as g };
                    let b_149: number;
                    export { b_149 as b };
                }
                export { rgb_149 as rgb };
                export namespace hsl_149 {
                    let h_298: number;
                    export { h_298 as h };
                    let s_149: number;
                    export { s_149 as s };
                    let l_298: number;
                    export { l_298 as l };
                }
                export { hsl_149 as hsl };
                export namespace oklch_149 {
                    let l_299: number;
                    export { l_299 as l };
                    let c_149: number;
                    export { c_149 as c };
                    let h_299: number;
                    export { h_299 as h };
                }
                export { oklch_149 as oklch };
                let accent_101: boolean;
                export { accent_101 as accent };
            }
            export { base_3 as base };
            export namespace mantle_3 {
                let name_178: string;
                export { name_178 as name };
                let order_130: number;
                export { order_130 as order };
                let hex_150: string;
                export { hex_150 as hex };
                export namespace rgb_150 {
                    let r_150: number;
                    export { r_150 as r };
                    let g_150: number;
                    export { g_150 as g };
                    let b_150: number;
                    export { b_150 as b };
                }
                export { rgb_150 as rgb };
                export namespace hsl_150 {
                    let h_300: number;
                    export { h_300 as h };
                    let s_150: number;
                    export { s_150 as s };
                    let l_300: number;
                    export { l_300 as l };
                }
                export { hsl_150 as hsl };
                export namespace oklch_150 {
                    let l_301: number;
                    export { l_301 as l };
                    let c_150: number;
                    export { c_150 as c };
                    let h_301: number;
                    export { h_301 as h };
                }
                export { oklch_150 as oklch };
                let accent_102: boolean;
                export { accent_102 as accent };
            }
            export { mantle_3 as mantle };
            export namespace crust_3 {
                let name_179: string;
                export { name_179 as name };
                let order_131: number;
                export { order_131 as order };
                let hex_151: string;
                export { hex_151 as hex };
                export namespace rgb_151 {
                    let r_151: number;
                    export { r_151 as r };
                    let g_151: number;
                    export { g_151 as g };
                    let b_151: number;
                    export { b_151 as b };
                }
                export { rgb_151 as rgb };
                export namespace hsl_151 {
                    let h_302: number;
                    export { h_302 as h };
                    let s_151: number;
                    export { s_151 as s };
                    let l_302: number;
                    export { l_302 as l };
                }
                export { hsl_151 as hsl };
                export namespace oklch_151 {
                    let l_303: number;
                    export { l_303 as l };
                    let c_151: number;
                    export { c_151 as c };
                    let h_303: number;
                    export { h_303 as h };
                }
                export { oklch_151 as oklch };
                let accent_103: boolean;
                export { accent_103 as accent };
            }
            export { crust_3 as crust };
        }
        export { colors_3 as colors };
        export namespace ansiColors_3 {
            export namespace black_3 {
                let name_180: string;
                export { name_180 as name };
                let order_132: number;
                export { order_132 as order };
                export namespace normal_24 {
                    let name_181: string;
                    export { name_181 as name };
                    let hex_152: string;
                    export { hex_152 as hex };
                    export namespace rgb_152 {
                        let r_152: number;
                        export { r_152 as r };
                        let g_152: number;
                        export { g_152 as g };
                        let b_152: number;
                        export { b_152 as b };
                    }
                    export { rgb_152 as rgb };
                    export namespace hsl_152 {
                        let h_304: number;
                        export { h_304 as h };
                        let s_152: number;
                        export { s_152 as s };
                        let l_304: number;
                        export { l_304 as l };
                    }
                    export { hsl_152 as hsl };
                    export namespace oklch_152 {
                        let l_305: number;
                        export { l_305 as l };
                        let c_152: number;
                        export { c_152 as c };
                        let h_305: number;
                        export { h_305 as h };
                    }
                    export { oklch_152 as oklch };
                    let code_48: number;
                    export { code_48 as code };
                }
                export { normal_24 as normal };
                export namespace bright_24 {
                    let name_182: string;
                    export { name_182 as name };
                    let hex_153: string;
                    export { hex_153 as hex };
                    export namespace rgb_153 {
                        let r_153: number;
                        export { r_153 as r };
                        let g_153: number;
                        export { g_153 as g };
                        let b_153: number;
                        export { b_153 as b };
                    }
                    export { rgb_153 as rgb };
                    export namespace hsl_153 {
                        let h_306: number;
                        export { h_306 as h };
                        let s_153: number;
                        export { s_153 as s };
                        let l_306: number;
                        export { l_306 as l };
                    }
                    export { hsl_153 as hsl };
                    export namespace oklch_153 {
                        let l_307: number;
                        export { l_307 as l };
                        let c_153: number;
                        export { c_153 as c };
                        let h_307: number;
                        export { h_307 as h };
                    }
                    export { oklch_153 as oklch };
                    let code_49: number;
                    export { code_49 as code };
                }
                export { bright_24 as bright };
            }
            export { black_3 as black };
            export namespace red_7 {
                let name_183: string;
                export { name_183 as name };
                let order_133: number;
                export { order_133 as order };
                export namespace normal_25 {
                    let name_184: string;
                    export { name_184 as name };
                    let hex_154: string;
                    export { hex_154 as hex };
                    export namespace rgb_154 {
                        let r_154: number;
                        export { r_154 as r };
                        let g_154: number;
                        export { g_154 as g };
                        let b_154: number;
                        export { b_154 as b };
                    }
                    export { rgb_154 as rgb };
                    export namespace hsl_154 {
                        let h_308: number;
                        export { h_308 as h };
                        let s_154: number;
                        export { s_154 as s };
                        let l_308: number;
                        export { l_308 as l };
                    }
                    export { hsl_154 as hsl };
                    export namespace oklch_154 {
                        let l_309: number;
                        export { l_309 as l };
                        let c_154: number;
                        export { c_154 as c };
                        let h_309: number;
                        export { h_309 as h };
                    }
                    export { oklch_154 as oklch };
                    let code_50: number;
                    export { code_50 as code };
                }
                export { normal_25 as normal };
                export namespace bright_25 {
                    let name_185: string;
                    export { name_185 as name };
                    let hex_155: string;
                    export { hex_155 as hex };
                    export namespace rgb_155 {
                        let r_155: number;
                        export { r_155 as r };
                        let g_155: number;
                        export { g_155 as g };
                        let b_155: number;
                        export { b_155 as b };
                    }
                    export { rgb_155 as rgb };
                    export namespace hsl_155 {
                        let h_310: number;
                        export { h_310 as h };
                        let s_155: number;
                        export { s_155 as s };
                        let l_310: number;
                        export { l_310 as l };
                    }
                    export { hsl_155 as hsl };
                    export namespace oklch_155 {
                        let l_311: number;
                        export { l_311 as l };
                        let c_155: number;
                        export { c_155 as c };
                        let h_311: number;
                        export { h_311 as h };
                    }
                    export { oklch_155 as oklch };
                    let code_51: number;
                    export { code_51 as code };
                }
                export { bright_25 as bright };
            }
            export { red_7 as red };
            export namespace green_7 {
                let name_186: string;
                export { name_186 as name };
                let order_134: number;
                export { order_134 as order };
                export namespace normal_26 {
                    let name_187: string;
                    export { name_187 as name };
                    let hex_156: string;
                    export { hex_156 as hex };
                    export namespace rgb_156 {
                        let r_156: number;
                        export { r_156 as r };
                        let g_156: number;
                        export { g_156 as g };
                        let b_156: number;
                        export { b_156 as b };
                    }
                    export { rgb_156 as rgb };
                    export namespace hsl_156 {
                        let h_312: number;
                        export { h_312 as h };
                        let s_156: number;
                        export { s_156 as s };
                        let l_312: number;
                        export { l_312 as l };
                    }
                    export { hsl_156 as hsl };
                    export namespace oklch_156 {
                        let l_313: number;
                        export { l_313 as l };
                        let c_156: number;
                        export { c_156 as c };
                        let h_313: number;
                        export { h_313 as h };
                    }
                    export { oklch_156 as oklch };
                    let code_52: number;
                    export { code_52 as code };
                }
                export { normal_26 as normal };
                export namespace bright_26 {
                    let name_188: string;
                    export { name_188 as name };
                    let hex_157: string;
                    export { hex_157 as hex };
                    export namespace rgb_157 {
                        let r_157: number;
                        export { r_157 as r };
                        let g_157: number;
                        export { g_157 as g };
                        let b_157: number;
                        export { b_157 as b };
                    }
                    export { rgb_157 as rgb };
                    export namespace hsl_157 {
                        let h_314: number;
                        export { h_314 as h };
                        let s_157: number;
                        export { s_157 as s };
                        let l_314: number;
                        export { l_314 as l };
                    }
                    export { hsl_157 as hsl };
                    export namespace oklch_157 {
                        let l_315: number;
                        export { l_315 as l };
                        let c_157: number;
                        export { c_157 as c };
                        let h_315: number;
                        export { h_315 as h };
                    }
                    export { oklch_157 as oklch };
                    let code_53: number;
                    export { code_53 as code };
                }
                export { bright_26 as bright };
            }
            export { green_7 as green };
            export namespace yellow_7 {
                let name_189: string;
                export { name_189 as name };
                let order_135: number;
                export { order_135 as order };
                export namespace normal_27 {
                    let name_190: string;
                    export { name_190 as name };
                    let hex_158: string;
                    export { hex_158 as hex };
                    export namespace rgb_158 {
                        let r_158: number;
                        export { r_158 as r };
                        let g_158: number;
                        export { g_158 as g };
                        let b_158: number;
                        export { b_158 as b };
                    }
                    export { rgb_158 as rgb };
                    export namespace hsl_158 {
                        let h_316: number;
                        export { h_316 as h };
                        let s_158: number;
                        export { s_158 as s };
                        let l_316: number;
                        export { l_316 as l };
                    }
                    export { hsl_158 as hsl };
                    export namespace oklch_158 {
                        let l_317: number;
                        export { l_317 as l };
                        let c_158: number;
                        export { c_158 as c };
                        let h_317: number;
                        export { h_317 as h };
                    }
                    export { oklch_158 as oklch };
                    let code_54: number;
                    export { code_54 as code };
                }
                export { normal_27 as normal };
                export namespace bright_27 {
                    let name_191: string;
                    export { name_191 as name };
                    let hex_159: string;
                    export { hex_159 as hex };
                    export namespace rgb_159 {
                        let r_159: number;
                        export { r_159 as r };
                        let g_159: number;
                        export { g_159 as g };
                        let b_159: number;
                        export { b_159 as b };
                    }
                    export { rgb_159 as rgb };
                    export namespace hsl_159 {
                        let h_318: number;
                        export { h_318 as h };
                        let s_159: number;
                        export { s_159 as s };
                        let l_318: number;
                        export { l_318 as l };
                    }
                    export { hsl_159 as hsl };
                    export namespace oklch_159 {
                        let l_319: number;
                        export { l_319 as l };
                        let c_159: number;
                        export { c_159 as c };
                        let h_319: number;
                        export { h_319 as h };
                    }
                    export { oklch_159 as oklch };
                    let code_55: number;
                    export { code_55 as code };
                }
                export { bright_27 as bright };
            }
            export { yellow_7 as yellow };
            export namespace blue_7 {
                let name_192: string;
                export { name_192 as name };
                let order_136: number;
                export { order_136 as order };
                export namespace normal_28 {
                    let name_193: string;
                    export { name_193 as name };
                    let hex_160: string;
                    export { hex_160 as hex };
                    export namespace rgb_160 {
                        let r_160: number;
                        export { r_160 as r };
                        let g_160: number;
                        export { g_160 as g };
                        let b_160: number;
                        export { b_160 as b };
                    }
                    export { rgb_160 as rgb };
                    export namespace hsl_160 {
                        let h_320: number;
                        export { h_320 as h };
                        let s_160: number;
                        export { s_160 as s };
                        let l_320: number;
                        export { l_320 as l };
                    }
                    export { hsl_160 as hsl };
                    export namespace oklch_160 {
                        let l_321: number;
                        export { l_321 as l };
                        let c_160: number;
                        export { c_160 as c };
                        let h_321: number;
                        export { h_321 as h };
                    }
                    export { oklch_160 as oklch };
                    let code_56: number;
                    export { code_56 as code };
                }
                export { normal_28 as normal };
                export namespace bright_28 {
                    let name_194: string;
                    export { name_194 as name };
                    let hex_161: string;
                    export { hex_161 as hex };
                    export namespace rgb_161 {
                        let r_161: number;
                        export { r_161 as r };
                        let g_161: number;
                        export { g_161 as g };
                        let b_161: number;
                        export { b_161 as b };
                    }
                    export { rgb_161 as rgb };
                    export namespace hsl_161 {
                        let h_322: number;
                        export { h_322 as h };
                        let s_161: number;
                        export { s_161 as s };
                        let l_322: number;
                        export { l_322 as l };
                    }
                    export { hsl_161 as hsl };
                    export namespace oklch_161 {
                        let l_323: number;
                        export { l_323 as l };
                        let c_161: number;
                        export { c_161 as c };
                        let h_323: number;
                        export { h_323 as h };
                    }
                    export { oklch_161 as oklch };
                    let code_57: number;
                    export { code_57 as code };
                }
                export { bright_28 as bright };
            }
            export { blue_7 as blue };
            export namespace magenta_3 {
                let name_195: string;
                export { name_195 as name };
                let order_137: number;
                export { order_137 as order };
                export namespace normal_29 {
                    let name_196: string;
                    export { name_196 as name };
                    let hex_162: string;
                    export { hex_162 as hex };
                    export namespace rgb_162 {
                        let r_162: number;
                        export { r_162 as r };
                        let g_162: number;
                        export { g_162 as g };
                        let b_162: number;
                        export { b_162 as b };
                    }
                    export { rgb_162 as rgb };
                    export namespace hsl_162 {
                        let h_324: number;
                        export { h_324 as h };
                        let s_162: number;
                        export { s_162 as s };
                        let l_324: number;
                        export { l_324 as l };
                    }
                    export { hsl_162 as hsl };
                    export namespace oklch_162 {
                        let l_325: number;
                        export { l_325 as l };
                        let c_162: number;
                        export { c_162 as c };
                        let h_325: number;
                        export { h_325 as h };
                    }
                    export { oklch_162 as oklch };
                    let code_58: number;
                    export { code_58 as code };
                }
                export { normal_29 as normal };
                export namespace bright_29 {
                    let name_197: string;
                    export { name_197 as name };
                    let hex_163: string;
                    export { hex_163 as hex };
                    export namespace rgb_163 {
                        let r_163: number;
                        export { r_163 as r };
                        let g_163: number;
                        export { g_163 as g };
                        let b_163: number;
                        export { b_163 as b };
                    }
                    export { rgb_163 as rgb };
                    export namespace hsl_163 {
                        let h_326: number;
                        export { h_326 as h };
                        let s_163: number;
                        export { s_163 as s };
                        let l_326: number;
                        export { l_326 as l };
                    }
                    export { hsl_163 as hsl };
                    export namespace oklch_163 {
                        let l_327: number;
                        export { l_327 as l };
                        let c_163: number;
                        export { c_163 as c };
                        let h_327: number;
                        export { h_327 as h };
                    }
                    export { oklch_163 as oklch };
                    let code_59: number;
                    export { code_59 as code };
                }
                export { bright_29 as bright };
            }
            export { magenta_3 as magenta };
            export namespace cyan_3 {
                let name_198: string;
                export { name_198 as name };
                let order_138: number;
                export { order_138 as order };
                export namespace normal_30 {
                    let name_199: string;
                    export { name_199 as name };
                    let hex_164: string;
                    export { hex_164 as hex };
                    export namespace rgb_164 {
                        let r_164: number;
                        export { r_164 as r };
                        let g_164: number;
                        export { g_164 as g };
                        let b_164: number;
                        export { b_164 as b };
                    }
                    export { rgb_164 as rgb };
                    export namespace hsl_164 {
                        let h_328: number;
                        export { h_328 as h };
                        let s_164: number;
                        export { s_164 as s };
                        let l_328: number;
                        export { l_328 as l };
                    }
                    export { hsl_164 as hsl };
                    export namespace oklch_164 {
                        let l_329: number;
                        export { l_329 as l };
                        let c_164: number;
                        export { c_164 as c };
                        let h_329: number;
                        export { h_329 as h };
                    }
                    export { oklch_164 as oklch };
                    let code_60: number;
                    export { code_60 as code };
                }
                export { normal_30 as normal };
                export namespace bright_30 {
                    let name_200: string;
                    export { name_200 as name };
                    let hex_165: string;
                    export { hex_165 as hex };
                    export namespace rgb_165 {
                        let r_165: number;
                        export { r_165 as r };
                        let g_165: number;
                        export { g_165 as g };
                        let b_165: number;
                        export { b_165 as b };
                    }
                    export { rgb_165 as rgb };
                    export namespace hsl_165 {
                        let h_330: number;
                        export { h_330 as h };
                        let s_165: number;
                        export { s_165 as s };
                        let l_330: number;
                        export { l_330 as l };
                    }
                    export { hsl_165 as hsl };
                    export namespace oklch_165 {
                        let l_331: number;
                        export { l_331 as l };
                        let c_165: number;
                        export { c_165 as c };
                        let h_331: number;
                        export { h_331 as h };
                    }
                    export { oklch_165 as oklch };
                    let code_61: number;
                    export { code_61 as code };
                }
                export { bright_30 as bright };
            }
            export { cyan_3 as cyan };
            export namespace white_3 {
                let name_201: string;
                export { name_201 as name };
                let order_139: number;
                export { order_139 as order };
                export namespace normal_31 {
                    let name_202: string;
                    export { name_202 as name };
                    let hex_166: string;
                    export { hex_166 as hex };
                    export namespace rgb_166 {
                        let r_166: number;
                        export { r_166 as r };
                        let g_166: number;
                        export { g_166 as g };
                        let b_166: number;
                        export { b_166 as b };
                    }
                    export { rgb_166 as rgb };
                    export namespace hsl_166 {
                        let h_332: number;
                        export { h_332 as h };
                        let s_166: number;
                        export { s_166 as s };
                        let l_332: number;
                        export { l_332 as l };
                    }
                    export { hsl_166 as hsl };
                    export namespace oklch_166 {
                        let l_333: number;
                        export { l_333 as l };
                        let c_166: number;
                        export { c_166 as c };
                        let h_333: number;
                        export { h_333 as h };
                    }
                    export { oklch_166 as oklch };
                    let code_62: number;
                    export { code_62 as code };
                }
                export { normal_31 as normal };
                export namespace bright_31 {
                    let name_203: string;
                    export { name_203 as name };
                    let hex_167: string;
                    export { hex_167 as hex };
                    export namespace rgb_167 {
                        let r_167: number;
                        export { r_167 as r };
                        let g_167: number;
                        export { g_167 as g };
                        let b_167: number;
                        export { b_167 as b };
                    }
                    export { rgb_167 as rgb };
                    export namespace hsl_167 {
                        let h_334: number;
                        export { h_334 as h };
                        let s_167: number;
                        export { s_167 as s };
                        let l_334: number;
                        export { l_334 as l };
                    }
                    export { hsl_167 as hsl };
                    export namespace oklch_167 {
                        let l_335: number;
                        export { l_335 as l };
                        let c_167: number;
                        export { c_167 as c };
                        let h_335: number;
                        export { h_335 as h };
                    }
                    export { oklch_167 as oklch };
                    let code_63: number;
                    export { code_63 as code };
                }
                export { bright_31 as bright };
            }
            export { white_3 as white };
        }
        export { ansiColors_3 as ansiColors };
    }
}
export default _default;
